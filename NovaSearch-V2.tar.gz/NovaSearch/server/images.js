'use strict';
const { getDb } = require('./database');

function initImagesTable() {
  // Tables are handled by database.js JSON shim
}

function extractImages($, sourceUrl) {
  const images = [];
  const seen   = new Set();
  $('img[src]').each((_, el) => {
    const rawSrc = $(el).attr('src');
    if (!rawSrc) return;
    let src;
    try { src = new URL(rawSrc, sourceUrl).href; } catch { return; }
    if (!src.startsWith('http://') && !src.startsWith('https://')) return;
    const w = parseInt($(el).attr('width')  || '999', 10);
    const h = parseInt($(el).attr('height') || '999', 10);
    if (w <= 2 || h <= 2) return;
    if (/\/(pixel|tracker|beacon|1x1)\//i.test(src)) return;
    if (seen.has(src)) return;
    seen.add(src);
    images.push({
      url:     src,
      altText: ($(el).attr('alt')   || '').trim().slice(0, 200),
      title:   ($(el).attr('title') || '').trim().slice(0, 200),
    });
    if (images.length >= 50) return false;
  });
  return images;
}

function saveImages(images, sourceUrl) {
  if (!images || !images.length) return;
  const db = getDb();
  let domain = '';
  try { domain = new URL(sourceUrl).hostname.replace(/^www\./, ''); } catch {}
  const ins = db.prepare('INSERT OR IGNORE INTO images (url, source_page, alt_text, title, domain, crawled_at) VALUES (?, ?, ?, ?, ?, datetime(\'now\'))');
  for (const img of images) {
    try { ins.run(img.url, sourceUrl, img.altText, img.title, domain); } catch {}
  }
}

function searchImages(query, page = 1, pageSize = 40) {
  const db = getDb();
  const offset = (page - 1) * pageSize;
  let rows;
  if (!query || !query.trim()) {
    rows = db.prepare('SELECT * FROM images ORDER BY crawled_at DESC LIMIT ? OFFSET ?').all(pageSize, offset);
  } else {
    const like = `%${query}%`;
    rows = db.prepare('SELECT * FROM images WHERE alt_text LIKE ? OR title LIKE ? OR domain LIKE ? LIMIT ? OFFSET ?').all(like, like, like, pageSize, offset);
  }
  const total = getImageCount();
  return {
    results: rows.map(r => ({ url: r.url, sourceUrl: r.source_page, alt_text: r.alt_text, title: r.title, domain: r.domain })),
    total, page, totalPages: Math.max(1, Math.ceil(total / pageSize)),
  };
}

function getImageCount() {
  try { return getDb().prepare('SELECT COUNT(*) as c FROM images').get().c; } catch { return 0; }
}

module.exports = { initImagesTable, extractImages, saveImages, searchImages, getImageCount };
