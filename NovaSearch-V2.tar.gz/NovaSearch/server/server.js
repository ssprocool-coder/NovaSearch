'use strict';

const express = require('express');
const path    = require('path');
const { getDb, resetDatabase }      = require('./database');
const { crawler }                   = require('./crawler');
const { search, getStats }          = require('./search');
const { searchImages, getImageCount }  = require('./images');
const { searchVideos, getVideoCount }  = require('./videos');
const { searchNews, getNewsCount }     = require('./news');
const { generateOverview, isConfigured, getProviderName } = require('./ai');

const app  = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

// ── Page routes (V1) ───────────────────────────────────────────────────────

app.get('/results', (_req, res) =>
  res.sendFile(path.join(__dirname, '..', 'public', 'results.html'))
);
app.get('/admin', (_req, res) =>
  res.sendFile(path.join(__dirname, '..', 'public', 'admin.html'))
);

// ── Page routes (V2) ───────────────────────────────────────────────────────

const v2page = (file) => (_req, res) =>
  res.sendFile(path.join(__dirname, '..', 'public', file));

app.get('/',            v2page('v2-index.html'));
app.get('/v2-index',   v2page('v2-index.html'));
app.get('/browser',    v2page('browser.html'));
app.get('/v2-results', v2page('v2-results.html'));
app.get('/v2-images',  v2page('v2-results.html'));  // same shell, different category
app.get('/v2-videos',  v2page('v2-results.html'));
app.get('/v2-news',    v2page('v2-results.html'));
app.get('/v2-history', v2page('v2-history.html'));
app.get('/v2-settings',v2page('v2-settings.html'));

// ── Search API ─────────────────────────────────────────────────────────────

app.get('/api/search', (req, res) => {
  const q    = (req.query.q || '').trim();
  const page = Math.max(1, parseInt(req.query.page || '1', 10));

  if (!q) return res.json({ query: q, total: 0, page, totalPages: 0, results: [], searchTime: 0 });

  const t0     = Date.now();
  const result = search(q, page);
  result.searchTime = Date.now() - t0;

  res.json(result);
});

// ── Image search API ───────────────────────────────────────────────────────

app.get('/api/images', (req, res) => {
  const q    = (req.query.q || '').trim();
  const page = Math.max(1, parseInt(req.query.page || '1', 10));
  res.json(searchImages(q, page));
});

// ── Video search API ───────────────────────────────────────────────────────

app.get('/api/videos', (req, res) => {
  const q    = (req.query.q || '').trim();
  const page = Math.max(1, parseInt(req.query.page || '1', 10));
  res.json(searchVideos(q, page));
});

// ── News search API ────────────────────────────────────────────────────────

app.get('/api/news', (req, res) => {
  const q    = (req.query.q || '').trim();
  const page = Math.max(1, parseInt(req.query.page || '1', 10));
  res.json(searchNews(q, page));
});

// ── AI overview API ────────────────────────────────────────────────────────

app.get('/api/ai/status', (_req, res) => {
  res.json({ available: isConfigured(), provider: getProviderName() });
});

app.post('/api/ai/overview', async (req, res) => {
  const { query, context } = req.body || {};
  if (!query) return res.json({ available: false });
  try {
    const result = await generateOverview(query, context || []);
    res.json(result);
  } catch (err) {
    res.json({ available: false, error: err.message });
  }
});

// ── Crawler API ────────────────────────────────────────────────────────────

app.post('/api/crawl', (req, res) => {
  const { url, maxPages = 50, maxDepth = 2, sameDomain = true } = req.body || {};

  if (!url || typeof url !== 'string') {
    return res.status(400).json({ error: 'url is required' });
  }

  // Safe URL check
  try {
    const u = new URL(url);
    if (!['http:', 'https:'].includes(u.protocol)) {
      return res.status(400).json({ error: 'Only http/https URLs allowed' });
    }
  } catch {
    return res.status(400).json({ error: 'Invalid URL' });
  }

  const mp = Math.min(Math.max(1, parseInt(maxPages, 10) || 50), 500);
  const md = Math.min(Math.max(1, parseInt(maxDepth, 10) || 2), 5);

  crawler.start({ url, maxPages: mp, maxDepth: md, sameDomain: Boolean(sameDomain) });

  res.json({
    started:    true,
    sessionId:  crawler.stats.sessionId,
    seedUrl:    url,
    maxPages:   mp,
    maxDepth:   md,
    sameDomain: Boolean(sameDomain),
  });
});

app.post('/api/crawl/stop', (_req, res) => {
  crawler.stop();
  res.json({ stopped: true });
});

app.get('/api/crawl/status', (_req, res) => {
  res.json(crawler.getStatus());
});

// ── Stats API ──────────────────────────────────────────────────────────────

app.get('/api/stats', (_req, res) => {
  const base = getStats();
  res.json({
    ...base,
    totalImages: getImageCount(),
    totalVideos: getVideoCount(),
    totalNews:   getNewsCount(),
  });
});

// ── Admin API ──────────────────────────────────────────────────────────────

app.get('/api/admin/sessions', (_req, res) => {
  const db   = getDb();
  const rows = db.prepare('SELECT * FROM crawl_sessions ORDER BY started_at DESC LIMIT 20').all();
  res.json({ sessions: rows });
});

app.get('/api/admin/pages', (req, res) => {
  const db     = getDb();
  const limit  = Math.min(parseInt(req.query.limit  || '20', 10), 100);
  const offset = Math.max(parseInt(req.query.offset || '0',  10), 0);
  const rows   = db.prepare('SELECT id, url, domain, title, crawled_at FROM pages ORDER BY crawled_at DESC LIMIT ? OFFSET ?').all(limit, offset);
  const total  = db.prepare('SELECT COUNT(*) as n FROM pages').get().n;
  res.json({ pages: rows, total, limit, offset });
});

app.delete('/api/admin/pages/:id', (req, res) => {
  const db  = getDb();
  const result = db.prepare('DELETE FROM pages WHERE id = ?').run(parseInt(req.params.id, 10));
  res.json({ deleted: result.changes > 0 });
});

app.post('/api/admin/reset', (_req, res) => {
  if (crawler.getStatus().status === 'running') {
    crawler.stop();
  }
  resetDatabase();
  res.json({ reset: true, message: 'Index cleared.' });
});

// ── Start ──────────────────────────────────────────────────────────────────

app.listen(PORT, () => {
  console.log(`NovaSearch V2 running → http://localhost:${PORT}`);
  console.log(`  Homepage:  http://localhost:${PORT}/`);
  console.log(`  Browser:   http://localhost:${PORT}/browser`);
  console.log(`  Admin:     http://localhost:${PORT}/admin`);
  console.log(`  AI status: ${isConfigured() ? getProviderName() + ' (enabled)' : 'Not configured (disabled)'}`);
});
