'use strict';
const { getDb } = require('./database');

function initVideosTable() {}

const VIDEO_EXT = /\.(mp4|webm|ogg|mov|avi|mkv)(\?|$)/i;
const VIDEO_DOMAINS = ['youtube.com','youtu.be','vimeo.com','dailymotion.com','twitch.tv','rumble.com'];

function extractVideos($, sourceUrl) {
  const videos = [];
  const seen   = new Set();
  function add(url, title, thumb) {
    if (seen.has(url) || videos.length >= 20) return;
    seen.add(url);
    videos.push({ url, title: (title||'').slice(0,200), thumbnailUrl: thumb||'', description: '' });
  }
  $('video[src], video source[src]').each((_, el) => {
    const src = $(el).attr('src');
    if (!src) return;
    try { const abs = new URL(src, sourceUrl).href; if (VIDEO_EXT.test(abs)) add(abs,'Video',''); } catch {}
  });
  $('iframe[src]').each((_, el) => {
    const src = $(el).attr('src') || $(el).attr('data-src') || '';
    if (!src) return;
    try {
      const abs  = new URL(src, sourceUrl).href;
      const host = new URL(abs).hostname.replace(/^www\./, '');
      if (!VIDEO_DOMAINS.some(d => host === d || host.endsWith('.'+d))) return;
      const ytM  = abs.match(/(?:youtube\.com\/embed\/|youtu\.be\/)([A-Za-z0-9_-]{11})/);
      const thumb = ytM ? `https://img.youtube.com/vi/${ytM[1]}/mqdefault.jpg` : '';
      add(abs, $(el).attr('title') || 'Embedded video', thumb);
    } catch {}
  });
  $('a[href]').each((_, el) => {
    const href = $(el).attr('href') || '';
    try {
      const abs  = new URL(href, sourceUrl).href;
      const host = new URL(abs).hostname.replace(/^www\./, '');
      if (VIDEO_EXT.test(abs) || VIDEO_DOMAINS.some(d => host === d || host.endsWith('.'+d))) {
        add(abs, $(el).text().trim() || host, '');
      }
    } catch {}
  });
  return videos;
}

function saveVideos(videos, sourceUrl) {
  if (!videos || !videos.length) return;
  const db = getDb();
  let domain = '';
  try { domain = new URL(sourceUrl).hostname.replace(/^www\./, ''); } catch {}
  const ins = db.prepare('INSERT OR IGNORE INTO videos (url, title, description, thumbnail_url, source_page, domain, crawled_at) VALUES (?, ?, ?, ?, ?, ?, datetime(\'now\'))');
  for (const v of videos) {
    try { ins.run(v.url, v.title, v.description, v.thumbnailUrl, sourceUrl, domain); } catch {}
  }
}

function searchVideos(query, page = 1, pageSize = 20) {
  const db = getDb();
  const offset = (page - 1) * pageSize;
  let rows;
  if (!query || !query.trim()) {
    rows = db.prepare('SELECT * FROM videos ORDER BY crawled_at DESC LIMIT ? OFFSET ?').all(pageSize, offset);
  } else {
    const like = `%${query}%`;
    rows = db.prepare('SELECT * FROM videos WHERE title LIKE ? OR description LIKE ? OR domain LIKE ? LIMIT ? OFFSET ?').all(like, like, like, pageSize, offset);
  }
  const total = getVideoCount();
  return {
    results: rows.map(r => ({ url: r.url, title: r.title, description: r.description, thumbnail_url: r.thumbnail_url, domain: r.domain })),
    total, page, totalPages: Math.max(1, Math.ceil(total / pageSize)),
  };
}

function getVideoCount() {
  try { return getDb().prepare('SELECT COUNT(*) as c FROM videos').get().c; } catch { return 0; }
}

module.exports = { initVideosTable, extractVideos, saveVideos, searchVideos, getVideoCount };
