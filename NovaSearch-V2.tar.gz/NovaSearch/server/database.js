'use strict';

// Android/Termux-friendly storage: plain JSON. No native modules.
const fs   = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', 'data');
const DB_PATH  = path.join(DATA_DIR, 'novasearch.json');
let state;

function emptyState() {
  return {
    pages: [], crawl_sessions: [], images: [], videos: [], news: [],
    nextPageId: 1, nextSessionId: 1, nextImageId: 1, nextVideoId: 1, nextNewsId: 1,
  };
}

function save() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const tmp = DB_PATH + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(state), 'utf8');
  fs.renameSync(tmp, DB_PATH);
}

function load() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(DB_PATH)) { state = emptyState(); save(); return; }
  try { state = JSON.parse(fs.readFileSync(DB_PATH, 'utf8')); }
  catch { state = emptyState(); save(); }
  // Ensure all collections exist (forward-compat)
  state.pages          ||= [];
  state.crawl_sessions ||= [];
  state.images         ||= [];
  state.videos         ||= [];
  state.news           ||= [];
  state.nextPageId     ||= Math.max(0, ...state.pages.map(p => p.id || 0)) + 1;
  state.nextSessionId  ||= Math.max(0, ...state.crawl_sessions.map(s => s.id || 0)) + 1;
  state.nextImageId    ||= Math.max(0, ...state.images.map(x => x.id || 0)) + 1;
  state.nextVideoId    ||= Math.max(0, ...state.videos.map(x => x.id || 0)) + 1;
  state.nextNewsId     ||= Math.max(0, ...state.news.map(x => x.id || 0)) + 1;
}

load();

function now() { return new Date().toISOString(); }

// ── Thin SQL-like prepare() shim ──────────────────────────────────────────

function prepare(sql) {
  return {

    get(...args) {
      if (/SELECT id, content_hash FROM pages WHERE url/i.test(sql)) {
        const p = state.pages.find(x => x.url === args[0]);
        return p ? { id: p.id, content_hash: p.content_hash || '' } : undefined;
      }
      if (/SELECT COUNT\(\*\) as n FROM pages/i.test(sql)) return { n: state.pages.length };
      if (/SELECT COUNT\(\*\) as n FROM images/i.test(sql)) return { n: state.images.length };
      if (/SELECT COUNT\(\*\) as n FROM videos/i.test(sql)) return { n: state.videos.length };
      if (/SELECT COUNT\(\*\) as n FROM news/i.test(sql))   return { n: state.news.length };
      // Stats queries
      if (/SELECT COUNT\(\*\) as c FROM pages/i.test(sql))  return { c: state.pages.length };
      if (/SELECT COUNT\(\*\) as c FROM images/i.test(sql)) return { c: state.images.length };
      if (/SELECT COUNT\(\*\) as c FROM videos/i.test(sql)) return { c: state.videos.length };
      if (/SELECT COUNT\(\*\) as c FROM news/i.test(sql))   return { c: state.news.length };
      if (/SELECT COUNT\(DISTINCT domain\)/i.test(sql))     return { n: new Set(state.pages.map(p => p.domain)).size };
      if (/SELECT MAX\(crawled_at\)/i.test(sql))            return { t: state.pages.map(p => p.crawled_at).sort().at(-1) || null };
      return undefined;
    },

    all(...args) {
      // Crawl sessions
      if (/SELECT \* FROM crawl_sessions/i.test(sql))
        return state.crawl_sessions.slice().sort((a,b)=>String(b.started_at).localeCompare(String(a.started_at))).slice(0,20);

      // Pages with full fields
      if (/SELECT .* FROM pages/i.test(sql)) {
        const rows = state.pages.slice().sort((a,b)=>String(b.crawled_at).localeCompare(String(a.crawled_at)));
        if (/description|headings|body_text/i.test(sql)) {
          const limit = Number(args[0]) || rows.length, offset = Number(args[1]) || 0;
          return rows.slice(offset, offset+limit).map(p => ({
            id:p.id, url:p.url, domain:p.domain, title:p.title,
            description:p.description, headings:p.headings,
            body_text:p.body_text, crawled_at:p.crawled_at,
          }));
        }
        const limit = Number(args[0]) || 20, offset = Number(args[1]) || 0;
        return rows.slice(offset, offset+limit).map(({id,url,domain,title,crawled_at})=>({id,url,domain,title,crawled_at}));
      }

      // Images
      if (/FROM images/i.test(sql)) {
        let rows = state.images.slice().sort((a,b)=>String(b.crawled_at).localeCompare(String(a.crawled_at)));
        if (/WHERE.*LIKE/i.test(sql) && args[0]) {
          const q = (args[0]+'').replace(/%/g,'').toLowerCase();
          rows = rows.filter(r =>
            (r.alt_text||'').toLowerCase().includes(q) ||
            (r.title||'').toLowerCase().includes(q) ||
            (r.domain||'').toLowerCase().includes(q)
          );
        }
        const limit = Number(args[args.length-2]) || 40, offset = Number(args[args.length-1]) || 0;
        return rows.slice(offset, offset+limit);
      }

      // Videos
      if (/FROM videos/i.test(sql)) {
        let rows = state.videos.slice().sort((a,b)=>String(b.crawled_at).localeCompare(String(a.crawled_at)));
        if (/WHERE.*LIKE/i.test(sql) && args[0]) {
          const q = (args[0]+'').replace(/%/g,'').toLowerCase();
          rows = rows.filter(r =>
            (r.title||'').toLowerCase().includes(q) ||
            (r.description||'').toLowerCase().includes(q) ||
            (r.domain||'').toLowerCase().includes(q)
          );
        }
        const limit = Number(args[args.length-2]) || 20, offset = Number(args[args.length-1]) || 0;
        return rows.slice(offset, offset+limit);
      }

      // News
      if (/FROM news/i.test(sql)) {
        let rows = state.news.slice().sort((a,b)=>String(b.published_at||b.crawled_at).localeCompare(String(a.published_at||a.crawled_at)));
        if (/WHERE.*LIKE/i.test(sql) && args[0]) {
          const q = (args[0]+'').replace(/%/g,'').toLowerCase();
          rows = rows.filter(r =>
            (r.title||'').toLowerCase().includes(q) ||
            (r.snippet||'').toLowerCase().includes(q) ||
            (r.source_domain||'').toLowerCase().includes(q)
          );
        }
        const limit = Number(args[args.length-2]) || 20, offset = Number(args[args.length-1]) || 0;
        return rows.slice(offset, offset+limit);
      }

      return [];
    },

    run(...args) {
      // ── crawl_sessions ───────────────────────────────────────────────
      if (/INSERT INTO crawl_sessions/i.test(sql)) {
        const [seed_url,max_pages,max_depth,same_domain] = args;
        const row = { id: state.nextSessionId++, started_at: now(), finished_at:null, seed_url, max_pages, max_depth, same_domain, pages_crawled:0, pages_skipped:0, errors:0, status:'running' };
        state.crawl_sessions.push(row); save(); return { lastInsertRowid: row.id, changes: 1 };
      }
      if (/UPDATE crawl_sessions\s+SET finished_at/i.test(sql)) {
        const [pages_crawled,pages_skipped,errors,status,id] = args;
        const s = state.crawl_sessions.find(x=>x.id===Number(id));
        if (s) Object.assign(s,{finished_at:now(),pages_crawled,pages_skipped,errors,status}); save(); return {changes:1};
      }

      // ── pages ─────────────────────────────────────────────────────────
      if (/UPDATE pages\s+SET domain=/i.test(sql)) {
        const [domain,title,description,headings,body_text,content_hash,url] = args;
        const p = state.pages.find(x=>x.url===url);
        if(p) Object.assign(p,{domain,title,description,headings,body_text,content_hash,crawled_at:now()}); save(); return {changes:p?1:0};
      }
      if (/INSERT INTO pages/i.test(sql)) {
        const [url,domain,title,description,headings,body_text,content_hash] = args;
        if (state.pages.some(p=>p.url===url)) { throw Object.assign(new Error('UNIQUE constraint failed: pages.url'), {code:'SQLITE_CONSTRAINT'}); }
        state.pages.push({id:state.nextPageId++,url,domain,title,description,headings,body_text,content_hash,crawled_at:now()}); save(); return {changes:1};
      }
      if (/DELETE FROM pages WHERE id/i.test(sql)) {
        const id=Number(args[0]); const before=state.pages.length;
        state.pages=state.pages.filter(p=>p.id!==id); save(); return {changes:before-state.pages.length};
      }

      // ── images ────────────────────────────────────────────────────────
      if (/INSERT OR IGNORE INTO images/i.test(sql)) {
        const [url,source_page,alt_text,title,domain] = args;
        if (state.images.some(x=>x.url===url)) return {changes:0};
        state.images.push({id:state.nextImageId++,url,source_page,alt_text,title,domain,crawled_at:now()}); save(); return {changes:1};
      }

      // ── videos ────────────────────────────────────────────────────────
      if (/INSERT OR IGNORE INTO videos/i.test(sql)) {
        const [url,title,description,thumbnail_url,source_page,domain] = args;
        if (state.videos.some(x=>x.url===url)) return {changes:0};
        state.videos.push({id:state.nextVideoId++,url,title,description,thumbnail_url,source_page,domain,crawled_at:now()}); save(); return {changes:1};
      }

      // ── news ──────────────────────────────────────────────────────────
      if (/INSERT OR IGNORE INTO news/i.test(sql)) {
        const [url,title,source_domain,published_at,snippet,thumbnail_url] = args;
        if (state.news.some(x=>x.url===url)) return {changes:0};
        state.news.push({id:state.nextNewsId++,url,title,source_domain,published_at,snippet,thumbnail_url,crawled_at:now()}); save(); return {changes:1};
      }

      return {changes:0};
    },
  };
}

// exec() is a no-op since we handle schema in-memory
function exec() {}

function getDb() { return { prepare, exec }; }

function resetDatabase() {
  state = emptyState(); save();
}

module.exports = { getDb, resetDatabase, DB_PATH };
