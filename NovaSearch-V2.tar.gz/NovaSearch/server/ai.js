'use strict';

/**
 * NovaSearch AI Overview Module
 *
 * This is a clean abstraction layer.
 * If no AI provider is configured, it returns available=false.
 * The frontend always shows search results regardless.
 *
 * Supported providers (configured via environment variables):
 *   NOVA_AI_PROVIDER=openai    + NOVA_AI_KEY=sk-...
 *   NOVA_AI_PROVIDER=anthropic + NOVA_AI_KEY=sk-ant-...
 *   NOVA_AI_PROVIDER=none      (default - AI disabled)
 *
 * To enable: create a .env file in the NovaSearch root:
 *   NOVA_AI_PROVIDER=anthropic
 *   NOVA_AI_KEY=your-key-here
 */

// Load optional .env
try {
  require('dotenv').config();
} catch {
  // dotenv not installed - use process.env directly
}

const PROVIDER = (process.env.NOVA_AI_PROVIDER || 'none').toLowerCase();
const AI_KEY   = process.env.NOVA_AI_KEY || '';

// ── Provider check ────────────────────────────────────────────────────────

function isConfigured() {
  return PROVIDER !== 'none' && AI_KEY.length > 10;
}

function getProviderName() {
  if (!isConfigured()) return 'Not configured';
  return PROVIDER.charAt(0).toUpperCase() + PROVIDER.slice(1);
}

// ── Build context from indexed documents ──────────────────────────────────

function buildContext(documents) {
  return documents.slice(0, 5).map((doc, i) =>
    `[${i + 1}] ${doc.title || doc.url}\n${doc.snippet || doc.description || ''}\nSource: ${doc.url}`
  ).join('\n\n');
}

function buildPrompt(query, context) {
  return `You are a search assistant for NovaSearch, a local search engine.
Answer the user's query using ONLY the provided indexed documents as context.
Be concise (2-3 sentences maximum).
If you are uncertain, say so clearly.
Do NOT invent information not in the documents.
Cite sources by number, e.g. [1], [2].

Query: ${query}

Indexed documents:
${context}

Provide a brief, factual answer based only on these sources:`;
}

// ── Provider implementations ──────────────────────────────────────────────

async function callOpenAI(query, documents) {
  const context = buildContext(documents);
  const prompt  = buildPrompt(query, context);

  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method:  'POST',
    headers: {
      'Content-Type':  'application/json',
      'Authorization': `Bearer ${AI_KEY}`,
    },
    body: JSON.stringify({
      model:      'gpt-3.5-turbo',
      messages:   [{ role: 'user', content: prompt }],
      max_tokens: 200,
      temperature: 0.3,
    }),
  });

  if (!res.ok) throw new Error(`OpenAI error ${res.status}`);

  const data = await res.json();
  return data.choices?.[0]?.message?.content?.trim() || '';
}

async function callAnthropic(query, documents) {
  const context = buildContext(documents);
  const prompt  = buildPrompt(query, context);

  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method:  'POST',
    headers: {
      'Content-Type':      'application/json',
      'x-api-key':         AI_KEY,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model:      'claude-haiku-4-5-20251001',
      max_tokens: 300,
      messages:   [{ role: 'user', content: prompt }],
    }),
  });

  if (!res.ok) throw new Error(`Anthropic error ${res.status}`);

  const data = await res.json();
  return data.content?.[0]?.text?.trim() || '';
}

// ── Main generate function ────────────────────────────────────────────────

async function generateOverview(query, documents) {
  if (!isConfigured()) {
    return { available: false };
  }

  if (!query || !documents || documents.length === 0) {
    return { available: false };
  }

  try {
    let answer;

    if (PROVIDER === 'openai') {
      answer = await callOpenAI(query, documents);
    } else if (PROVIDER === 'anthropic') {
      answer = await callAnthropic(query, documents);
    } else {
      return { available: false };
    }

    // Build source list from actual documents used
    const sources = documents.slice(0, 5).map(doc => ({
      url:   doc.url,
      title: doc.title || doc.url,
    }));

    return {
      available: true,
      provider:  getProviderName(),
      answer,
      sources,
      note: 'Answer generated from your indexed local documents.',
    };

  } catch (err) {
    console.error('[AI] Overview error:', err.message);
    return {
      available: false,
      error: 'AI overview temporarily unavailable.',
    };
  }
}

module.exports = { generateOverview, isConfigured, getProviderName };
