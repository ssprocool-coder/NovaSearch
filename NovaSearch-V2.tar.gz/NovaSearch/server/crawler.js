'use strict';

const crypto  = require('crypto');
const axios   = require('axios');
const { getDb }           = require('./database');
const { parseHtml }       = require('./parser');
const { isAllowed }       = require('./robots');
const { saveImages }      = require('./images');
const { saveVideos }      = require('./videos');
const { saveNewsPage }    = require('./news');
const {
  normalizeUrl, isValidUrl, getDomain, isSameDomain, shouldSkipUrl,
} = require('./url-utils');

const USER_AGENT      = 'NovaSearchBot/1.0 (+http://localhost:3000/bot)';
const REQ_TIMEOUT_MS  = 12000;
const MAX_BODY_BYTES  = 4 * 1024 * 1024; // 4 MB
const RATE_DELAY_MS   = 600;              // min ms between requests to same domain
const CONCURRENCY     = 3;               // simultaneous fetches
const HARD_PAGE_CAP   = 500;             // absolute upper limit regardless of user input

// ── Helper ─────────────────────────────────────────────────────────────────

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

function contentHash(text) {
  return crypto.createHash('sha256').update(text || '').digest('hex');
}

// ── Crawler class ──────────────────────────────────────────────────────────

class Crawler {
  constructor() {
    this._reset();
  }

  _reset() {
    this.active         = false;
    this.sessionId      = null;
    this.globalQueue    = [];       // { url, depth }
    this.visited        = new Set();
    this.domainQueues   = new Map(); // domain -> [{ url, depth }]
    this.domainWorking  = new Map(); // domain -> boolean (is currently fetching)
    this.domainLastRequestAt = new Map(); // domain -> timestamp of last page fetch
    this.stats = {
      status:       'idle',
      pagesCrawled: 0,
      pagesSkipped: 0,
      errors:       0,
      currentUrl:   null,
      seedUrl:      null,
      maxPages:     0,
      maxDepth:     0,
      startedAt:    null,
    };
  }

  /** Start a crawl. Returns immediately; crawl runs in background. */
  start(opts) {
    if (this.active) {
      return { error: 'Crawler is already running. Stop it first.' };
    }

    const {
      url: rawSeed,
      maxPages   = 50,
      maxDepth   = 2,
      sameDomain = true,
    } = opts || {};

    if (!isValidUrl(rawSeed)) {
      return { error: 'Invalid seed URL. Must start with http:// or https://' };
    }

    const seedUrl  = normalizeUrl(rawSeed, rawSeed) || rawSeed;
    const capPages = Math.min(Math.max(parseInt(maxPages) || 50, 1), HARD_PAGE_CAP);
    const capDepth = Math.min(Math.max(parseInt(maxDepth) || 2, 0), 10);

    // Persist session record
    const db  = getDb();
    const row = db.prepare(`
      INSERT INTO crawl_sessions (started_at, seed_url, max_pages, max_depth, same_domain, status)
      VALUES (datetime('now'), ?, ?, ?, ?, 'running')
    `).run(seedUrl, capPages, capDepth, sameDomain ? 1 : 0);

    this.sessionId = row.lastInsertRowid;
    this.active    = true;
    this.globalQueue = [{ url: seedUrl, depth: 0 }];
    this.visited     = new Set([seedUrl]);
    this.domainQueues = new Map();
    this.domainWorking = new Map();
    this.domainLastRequestAt = new Map();

    Object.assign(this.stats, {
      status:       'running',
      pagesCrawled: 0,
      pagesSkipped: 0,
      errors:       0,
      currentUrl:   seedUrl,
      seedUrl,
      maxPages:     capPages,
      maxDepth:     capDepth,
      startedAt:    new Date().toISOString(),
    });

    // Fire-and-forget
    this._run(capPages, capDepth, sameDomain, seedUrl)
      .then(() => this._finish('finished'))
      .catch(err => {
        console.error('[Crawler] Fatal error:', err.message);
        this._finish('error');
      });

    return { started: true, sessionId: this.sessionId, seedUrl, maxPages: capPages, maxDepth: capDepth };
  }

  /** Gracefully stop the running crawl. */
  stop() {
    if (!this.active) return { error: 'No crawl is running.' };
    this.active = false;
    this.stats.status = 'stopping';
    return { stopped: true };
  }

  /** Return a snapshot of current status. */
  getStatus() {
    return { ...this.stats };
  }

  // ── Internal ──────────────────────────────────────────────────────────────

  async _run(maxPages, maxDepth, sameDomain, seedUrl) {
    // Start CONCURRENCY domain workers in parallel
    const workers = [];
    for (let i = 0; i < CONCURRENCY; i++) {
      workers.push(this._domainWorker(maxPages, maxDepth, sameDomain, seedUrl));
    }
    await Promise.all(workers);
  }

  async _domainWorker(maxPages, maxDepth, sameDomain, seedUrl) {
    while (this.active && this.stats.pagesCrawled < maxPages) {
      // Move newly discovered URLs into per-domain queues.
      if (this.globalQueue.length) {
        const item = this.globalQueue.shift();
        const d = getDomain(item.url);
        if (!this.domainQueues.has(d)) this.domainQueues.set(d, []);
        this.domainQueues.get(d).push(item);
        continue;
      }

      // Grab the next domain with pending work. Each domain is serialized,
      // so two workers can never fetch the same domain concurrently.
      let domain = null;
      for (const [d, q] of this.domainQueues) {
        if (q.length > 0 && !this.domainWorking.get(d)) {
          domain = d;
          break;
        }
      }

      if (!domain) {
        // There may still be work being processed by another worker. Wait
        // briefly rather than exiting and accidentally abandoning queued URLs.
        if (this._hasPendingWork()) {
          await sleep(25);
          continue;
        }
        break;
      }

      this.domainWorking.set(domain, true);
      const item = this.domainQueues.get(domain).shift();

      try {
        await this._handleItem(item, maxPages, maxDepth, sameDomain, seedUrl);
      } finally {
        this.domainWorking.set(domain, false);
      }
    }
  }

  _hasPendingWork() {
    if (this.globalQueue.length > 0) return true;
    for (const q of this.domainQueues.values()) {
      if (q.length > 0) return true;
    }
    for (const busy of this.domainWorking.values()) {
      if (busy) return true;
    }
    return false;
  }

  async _waitForDomainRateLimit(domain) {
    const last = this.domainLastRequestAt.get(domain) || 0;
    const waitMs = RATE_DELAY_MS - (Date.now() - last);
    if (waitMs > 0) await sleep(waitMs);
  }

  async _handleItem(item, maxPages, maxDepth, sameDomain, seedUrl) {
    if (!this.active || this.stats.pagesCrawled >= maxPages) return;

    const { url, depth } = item;

    // Depth guard
    if (depth > maxDepth) {
      this.stats.pagesSkipped++;
      return;
    }

    // File-extension filter
    if (shouldSkipUrl(url)) {
      this.stats.pagesSkipped++;
      return;
    }

    this.stats.currentUrl = url;

    // robots.txt check
    try {
      if (!(await isAllowed(url))) {
        this.stats.pagesSkipped++;
        return;
      }
    } catch { /* treat as allowed */ }

    // Fetch + index
    try {
      const result = await this._fetchAndIndex(url);
      if (result.success) {
        this.stats.pagesCrawled++;
        // Enqueue discovered links
        if (depth < maxDepth && result.links?.length) {
          this._enqueueLinks(result.links, url, depth + 1, sameDomain, seedUrl, maxPages);
        }
      } else if (result.skip) {
        this.stats.pagesSkipped++;
      } else {
        this.stats.errors++;
      }
    } catch (err) {
      console.error(`[Crawler] ${url} — ${err.message}`);
      this.stats.errors++;
    }
  }

  _enqueueLinks(links, baseUrl, depth, sameDomain, seedUrl, maxPages) {
    for (const href of links) {
      const normalized = normalizeUrl(href, baseUrl);
      if (!normalized) continue;
      if (this.visited.has(normalized)) continue;
      if (sameDomain && !isSameDomain(normalized, seedUrl)) continue;
      if (shouldSkipUrl(normalized)) continue;

      this.visited.add(normalized);
      this.globalQueue.push({ url: normalized, depth });

      // Don't let the queue grow unboundedly
      if (this.globalQueue.length > maxPages * 5) break;
    }
  }

  async _fetchAndIndex(url) {
    const db = getDb();

    // Enforce a real minimum gap between page requests to the same domain.
    // Per-domain serialization prevents overlapping requests; this timestamp
    // enforces the actual 600ms spacing as well.
    const requestDomain = getDomain(url);
    await this._waitForDomainRateLimit(requestDomain);
    this.domainLastRequestAt.set(requestDomain, Date.now());

    // HTTP GET
    let response;
    try {
      response = await axios.get(url, {
        timeout:          REQ_TIMEOUT_MS,
        maxContentLength: MAX_BODY_BYTES,
        maxRedirects:     5,
        responseType:     'text',
        headers: {
          'User-Agent':      USER_AGENT,
          'Accept':          'text/html,application/xhtml+xml;q=0.9,*/*;q=0.7',
          'Accept-Language': 'en-US,en;q=0.5',
          'Accept-Encoding': 'gzip, deflate',
        },
        validateStatus: s => s < 400,
      });
    } catch (err) {
      const status = err.response?.status;
      if (status && status >= 400) {
        return { success: false, error: `HTTP ${status}` };
      }
      throw err; // network error — let caller count as error
    }

    // Content-type guard
    const ct = (response.headers['content-type'] || '').toLowerCase();
    if (!ct.includes('text/html') && !ct.includes('application/xhtml')) {
      return { success: false, skip: true };
    }

    const html = response.data;
    if (!html || html.trim().length < 50) {
      return { success: false, skip: true };
    }

    // Parse
    const parsed = parseHtml(html, url);
    const domain = getDomain(url);

    // Compute content hash for deduplication
    const contentData = [parsed.title, parsed.description, parsed.headings, parsed.bodyText].join('\n');
    const hash = contentHash(contentData);

    // Check if this content has been seen before
    const existing = db.prepare('SELECT id, content_hash FROM pages WHERE url = ?').get(url);
    if (existing && existing.content_hash === hash) {
      // Content hasn't changed — skip update
      return { success: true, links: parsed.links };
    }

    // Upsert into database
    if (existing) {
      db.prepare(`
        UPDATE pages
        SET domain=?, title=?, description=?, headings=?, body_text=?, content_hash=?, crawled_at=datetime('now')
        WHERE url=?
      `).run(domain, parsed.title, parsed.description, parsed.headings, parsed.bodyText, hash, url);
    } else {
      try {
        db.prepare(`
          INSERT INTO pages (url, domain, title, description, headings, body_text, content_hash, crawled_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
        `).run(url, domain, parsed.title, parsed.description, parsed.headings, parsed.bodyText, hash);
      } catch (e) {
        if (!e.message?.includes('UNIQUE')) throw e;
        // Duplicate URL (race condition) — that's fine
      }
    }

    // Save media discovered on this page (V2)
    if (parsed.images && parsed.images.length > 0) {
      try { saveImages(parsed.images, url); } catch { /* non-fatal */ }
    }
    if (parsed.videos && parsed.videos.length > 0) {
      try { saveVideos(parsed.videos, url); } catch { /* non-fatal */ }
    }
    if (parsed.newsPage && parsed.newsData) {
      try { saveNewsPage(parsed.newsData, url); } catch { /* non-fatal */ }
    }

    return { success: true, links: parsed.links };
  }

  _finish(status) {
    if (this.sessionId) {
      try {
        getDb().prepare(`
          UPDATE crawl_sessions
          SET finished_at=datetime('now'), pages_crawled=?, pages_skipped=?, errors=?, status=?
          WHERE id=?
        `).run(
          this.stats.pagesCrawled,
          this.stats.pagesSkipped,
          this.stats.errors,
          status,
          this.sessionId
        );
      } catch { /* best effort */ }
    }

    this.active           = false;
    this.stats.status     = status;
    this.stats.currentUrl = null;
    this.sessionId        = null;
  }
}

// Singleton
const crawler = new Crawler();
module.exports = { crawler };
