'use strict';

const { getDb } = require('./database');
const PAGE_SIZE = 10;

function tokenize(text) { return String(text || '').toLowerCase().match(/[a-z0-9]+/g) || []; }
function count(tokens, term) { let n=0; for(const t of tokens) if(t===term)n++; return n; }
function search(query, page=1) {
  query=(query||'').trim(); if(!query) return {query,total:0,results:[],error:'Empty query'};
  const db=getDb(); const totalDocs=db.prepare('SELECT COUNT(*) as n FROM pages').get().n;
  if(!totalDocs) return {query,total:0,results:[],message:'No pages have been indexed yet. Open the Admin panel to crawl websites first.'};
  const pages=db.prepare('SELECT id, url, domain, title, description, headings, body_text, crawled_at FROM pages ORDER BY crawled_at DESC LIMIT ? OFFSET ?').all(totalDocs,0);
  const terms=tokenize(query); const df=new Map(); const cache=new Map();
  for(const p of pages){const toks=tokenize(`${p.title} ${p.description} ${p.headings} ${p.body_text} ${p.url}`); cache.set(p.id,toks); for(const t of new Set(toks)) df.set(t,(df.get(t)||0)+1);}
  const avg=pages.reduce((s,p)=>s+cache.get(p.id).length,0)/Math.max(1,pages.length);
  const scored=[];
  for(const p of pages){
    const title=tokenize(p.title), headings=tokenize(p.headings), desc=tokenize(p.description), body=tokenize(p.body_text), url=tokenize(p.url), all=cache.get(p.id);
    let score=0, matched=0;
    for(const term of terms){
      const d=df.get(term)||0, idf=Math.log(1+(totalDocs-d+0.5)/(d+0.5));
      const w=10*count(title,term)+6*count(headings,term)+5*count(desc,term)+3*count(url,term)+count(body,term);
      if(w) matched++; const k1=1.2,b=.75,norm=1-b+b*(all.length/Math.max(avg,1)); score += idf*((w*(k1+1))/(w+k1*norm));
    }
    if(!matched) continue;
    const titleText=title.join(' '); if(titleText===terms.join(' '))score+=8;
    const phrase=terms.join(' '), combined=all.join(' '); if(terms.length>1 && combined.includes(phrase))score+=3;
    score*=0.5+0.5*(matched/terms.length);
    const source=p.description||p.body_text||p.headings||'';
    scored.push({title:p.title||p.url,url:p.url,description:source.slice(0,300),domain:p.domain,score,crawledAt:p.crawled_at});
  }
  scored.sort((a,b)=>b.score-a.score); const total=scored.length, totalPages=Math.ceil(total/PAGE_SIZE); page=Math.max(1,page);
  const max=scored[0]?.score||1; const results=scored.slice((page-1)*PAGE_SIZE,page*PAGE_SIZE).map(r=>({...r,score:Math.max(0,Math.min(1,r.score/max))}));
  return {query,total,page,totalPages,results};
}
function getStats(){const db=getDb(); return {totalPages:db.prepare('SELECT COUNT(*) as n FROM pages').get().n,totalDomains:db.prepare('SELECT COUNT(DISTINCT domain) as n FROM pages').get().n,lastCrawl:db.prepare('SELECT MAX(crawled_at) as t FROM pages').get().t};}
module.exports={search,getStats};
