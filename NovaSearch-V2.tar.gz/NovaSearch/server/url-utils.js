'use strict';

const { URL } = require('url');

const SKIP_EXTENSIONS = new Set([
  '.jpg', '.jpeg', '.png', '.gif', '.svg', '.webp', '.ico', '.bmp', '.tiff',
  '.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx', '.odt', '.ods',
  '.zip', '.rar', '.tar', '.gz', '.7z', '.bz2',
  '.mp3', '.mp4', '.wav', '.avi', '.mov', '.mkv', '.flac', '.ogg', '.webm',
  '.css', '.js', '.json', '.xml', '.rss', '.atom', '.txt',
  '.woff', '.woff2', '.ttf', '.eot', '.otf',
  '.exe', '.dmg', '.pkg', '.deb', '.rpm',
]);

/**
 * Normalize a URL: resolve relative URLs, strip fragment, normalize trailing slash.
 * Returns null if the URL is invalid or unsafe.
 */
function normalizeUrl(rawUrl, baseUrl) {
  if (!rawUrl || typeof rawUrl !== 'string') return null;
  rawUrl = rawUrl.trim();
  if (!rawUrl || rawUrl.startsWith('javascript:') || rawUrl.startsWith('data:')) return null;

  try {
    const url = new URL(rawUrl, baseUrl);
    if (!['http:', 'https:'].includes(url.protocol)) return null;

    // Strip fragment
    url.hash = '';

    // Normalize trailing slash on paths (preserve root /)
    if (url.pathname !== '/' && url.pathname.endsWith('/')) {
      url.pathname = url.pathname.slice(0, -1);
    }

    // Decode then re-encode path to normalize percent-encoding
    try {
      url.pathname = encodeURI(decodeURIComponent(url.pathname));
    } catch { /* leave as-is */ }

    return url.href;
  } catch {
    return null;
  }
}

/**
 * Basic URL validation — must be http/https with a real-looking host.
 */
function isValidUrl(url) {
  if (!url || typeof url !== 'string') return false;
  try {
    const u = new URL(url.trim());
    if (!['http:', 'https:'].includes(u.protocol)) return false;
    if (!u.hostname || u.hostname.length < 2) return false;
    return true;
  } catch {
    return false;
  }
}

/** Extract just the hostname from a URL. */
function getDomain(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, '');
  } catch {
    return '';
  }
}

/** Return true if both URLs share the same hostname (www-insensitive). */
function isSameDomain(urlA, urlB) {
  return getDomain(urlA) === getDomain(urlB);
}

/** Return true if this URL's extension should be skipped. */
function shouldSkipUrl(url) {
  try {
    const u = new URL(url);
    const pathname = u.pathname.toLowerCase().split('?')[0];
    const ext = pathname.substring(pathname.lastIndexOf('.'));
    return SKIP_EXTENSIONS.has(ext);
  } catch {
    return true;
  }
}

module.exports = { normalizeUrl, isValidUrl, getDomain, isSameDomain, shouldSkipUrl };
