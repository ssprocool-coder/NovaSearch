'use strict';

const axios = require('axios');
const robotsParser = require('robots-parser');

const BOT_NAME   = 'NovaSearchBot';
const USER_AGENT = 'NovaSearchBot/1.0 (+http://localhost:3000/bot)';
const CACHE_TTL  = 60 * 60 * 1000; // 1 hour

/** Cache: domain -> { robots, timestamp } */
const cache = new Map();

/**
 * Fetch and cache robots.txt for the given origin (protocol + hostname).
 * Returns a robots-parser instance, or null if robots.txt is unavailable.
 */
async function fetchRobots(origin) {
  const cached = cache.get(origin);
  if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
    return cached.robots;
  }

  const robotsUrl = `${origin}/robots.txt`;
  let robots = null;

  try {
    const res = await axios.get(robotsUrl, {
      timeout: 8000,
      maxContentLength: 512 * 1024,
      headers: { 'User-Agent': USER_AGENT },
      maxRedirects: 3,
      validateStatus: s => s < 500,
    });

    if (res.status === 200 && typeof res.data === 'string') {
      robots = robotsParser(robotsUrl, res.data);
    }
  } catch {
    // Treat as no restrictions
  }

  cache.set(origin, { robots, timestamp: Date.now() });
  return robots;
}

/**
 * Return true if NovaSearchBot is allowed to crawl `url`.
 * Defaults to true if robots.txt cannot be fetched.
 */
async function isAllowed(url) {
  try {
    const u = new URL(url);
    const origin = `${u.protocol}//${u.hostname}`;
    const robots = await fetchRobots(origin);
    if (!robots) return true;
    const result = robots.isAllowed(url, BOT_NAME);
    return result !== false; // null means "not specified" → allow
  } catch {
    return true;
  }
}

module.exports = { isAllowed };
