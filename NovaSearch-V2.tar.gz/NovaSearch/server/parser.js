'use strict';

const cheerio = require('cheerio');
const { extractImages } = require('./images');
const { extractVideos } = require('./videos');
const { isNewsPage, extractNewsData } = require('./news');

const NOISE_SELECTORS = [
  'script','style','noscript','object','embed',
  'nav','header','footer','.nav','.navbar','.footer','.sidebar',
  '.ad','.ads','.advertisement','.cookie-banner','.popup',
  '[aria-hidden="true"]','.hidden','.visually-hidden',
];

const CONTENT_SELECTORS = [
  'main','article','[role="main"]','.content','.main-content',
  '#content','#main','.post','.post-body','.post-content',
  '.entry-content','.article-body','.page-content','.text-content',
];

function parseHtml(html, url) {
  let $;
  try { $ = cheerio.load(html, { decodeEntities: true }); }
  catch { return emptyResult(url); }

  // Extract media BEFORE removing noise (iframes hold video embeds)
  const images   = extractImages($, url);
  const videos   = extractVideos($, url);
  const newsFlag = isNewsPage($, url);

  // Now strip noise for text extraction
  $(NOISE_SELECTORS.join(',')).remove();

  const title = cleanText(
    $('title').first().text() ||
    $('meta[property="og:title"]').attr('content') ||
    $('h1').first().text() || ''
  ).slice(0, 512);

  const description = cleanText(
    $('meta[name="description"]').attr('content') ||
    $('meta[property="og:description"]').attr('content') ||
    $('meta[name="twitter:description"]').attr('content') || ''
  ).slice(0, 1024);

  const canonical = ($('link[rel="canonical"]').attr('href') || url).trim();

  const headingParts = [];
  $('h1,h2,h3,h4').each((_, el) => {
    const t = cleanText($(el).text());
    if (t) headingParts.push(t);
  });
  const headings = headingParts.join(' | ').slice(0, 2048);

  let bodyEl = null;
  for (const sel of CONTENT_SELECTORS) {
    const el = $(sel).first();
    if (el.length && el.text().trim().length > 100) { bodyEl = el; break; }
  }
  const bodyText = cleanText((bodyEl ? bodyEl.text() : $('body').text())).slice(0, 50000);

  const links = [];
  $('a[href]').each((_, el) => {
    const href = ($(el).attr('href') || '').trim();
    if (href && !href.startsWith('#') && !href.startsWith('mailto:') &&
        !href.startsWith('tel:') && !href.startsWith('javascript:')) {
      links.push(href);
    }
  });

  const newsData = newsFlag
    ? extractNewsData($, url, { title, description, bodyText })
    : null;

  return { title, description, headings, bodyText, canonical, links, images, videos, newsPage: newsFlag, newsData };
}

function cleanText(text) {
  if (!text) return '';
  return text.replace(/[<>"'&\0]/g,' ').replace(/\s+/g,' ').trim();
}

function emptyResult(url) {
  return { title:url, description:'', headings:'', bodyText:'', canonical:url, links:[], images:[], videos:[], newsPage:false, newsData:null };
}

module.exports = { parseHtml };
