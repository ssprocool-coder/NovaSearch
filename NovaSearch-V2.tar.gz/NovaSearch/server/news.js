'use strict';
const { getDb } = require('./database');

function initNewsTable() {}

function isNewsPage($, url) {
  let score = 0;
  if (/\/(news|article|story|post|blog|press)\//i.test(url)) score += 3;
  if ($('meta[property="og:type"][content="article"]').length) score += 2;
  if ($('[itemprop="NewsArticle"], article').length) score += 2;
  if ($('time[datetime], [itemprop="datePublished"]').length) score += 2;
  if ($('[class*="author"], [itemprop="author"]').length) score += 1;
  if (($('article,main').text()||'').trim().length > 500) score += 1;
  return score >= 4;
}

function extractPublishedDate($) {
  const selectors = [
    () => $('time[datetime]').first().attr('datetime'),
    () => $('meta[property="article:published_time"]').attr('content'),
    () => $('[itemprop="datePublished"]').first().attr('content') || $('[itemprop="datePublished"]').first().text(),
    () => $('meta[name="pubdate"]').attr('content'),
  ];
  for (const sel of selectors) {
    const val = sel();
    if (!val) continue;
    const d = new Date(val);
    if (!isNaN(d.getTime()) && d.getFullYear() >= 2000) return d.toISOString();
  }
  return '';
}

function extractNewsData($, url, parsed) {
  const publishedAt = extractPublishedDate($);
  let thumbnailUrl = $('meta[property="og:image"]').attr('content') || '';
  if (!thumbnailUrl) {
    const src = $('article img, main img').first().attr('src');
    if (src) { try { thumbnailUrl = new URL(src, url).href; } catch {} }
  }
  return {
    url, title: parsed.title,
    publishedAt, thumbnailUrl,
    snippet: (parsed.description || parsed.bodyText.slice(0, 200)).trim(),
  };
}

function saveNewsPage(data, sourceUrl) {
  if (!data) return;
  const db = getDb();
  let domain = '';
  try { domain = new URL(sourceUrl).hostname.replace(/^www\./, ''); } catch {}
  try {
    db.prepare('INSERT OR IGNORE INTO news (url, title, source_domain, published_at, snippet, thumbnail_url, crawled_at) VALUES (?, ?, ?, ?, ?, ?, datetime(\'now\'))').run(data.url, data.title, domain, data.publishedAt, data.snippet, data.thumbnailUrl);
  } catch {}
}

function searchNews(query, page = 1, pageSize = 20) {
  const db = getDb();
  const offset = (page - 1) * pageSize;
  let rows;
  if (!query || !query.trim()) {
    rows = db.prepare('SELECT * FROM news ORDER BY published_at DESC LIMIT ? OFFSET ?').all(pageSize, offset);
  } else {
    const like = `%${query}%`;
    rows = db.prepare('SELECT * FROM news WHERE title LIKE ? OR snippet LIKE ? OR source_domain LIKE ? LIMIT ? OFFSET ?').all(like, like, like, pageSize, offset);
  }
  const total = getNewsCount();
  return {
    results: rows.map(r => ({ url: r.url, title: r.title, source_domain: r.source_domain, published_at: r.published_at, snippet: r.snippet, thumbnail_url: r.thumbnail_url })),
    total, page, totalPages: Math.max(1, Math.ceil(total / pageSize)),
  };
}

function getNewsCount() {
  try { return getDb().prepare('SELECT COUNT(*) as c FROM news').get().c; } catch { return 0; }
}

module.exports = { initNewsTable, isNewsPage, extractNewsData, saveNewsPage, searchNews, getNewsCount };
