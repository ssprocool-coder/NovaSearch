# NovaSearch V2 — Development Guide

## Overview

NovaSearch V2 transforms V1 from a simple search interface into a complete mobile search engine + browser experience.

### What's New in V2

- ✅ Browser-style home page with shortcuts
- ✅ In-app browser with tab management
- ✅ Search suggestions (from history)
- ✅ Recently visited pages
- ✅ Android WebView application shell
- 🔄 Image/video indexing (STAGES 4-5)
- 🔄 News results (STAGE 6)
- 🔄 Maps integration (STAGE 7)
- 🔄 AI overview (STAGE 8)

---

## Architecture

```
┌─────────────────────────────────────────────────────┐
│         NovaSearch Android App (WebView)            │
│  ┌───────────────────────────────────────────────┐  │
│  │  Browser Shell (Kotlin/AndroidManifest.xml)  │  │
│  │  - Safe URL handling                        │  │
│  │  - Back button integration                  │  │
│  │  - External link routing                    │  │
│  └───────────────────────────────────────────────┘  │
└──────────────────────────┬──────────────────────────┘
                           │
                           ↓
        ┌──────────────────────────────────────┐
        │  NovaSearch Web Frontend (HTML/CSS/JS)│
        │  ├─ /v2-index (homepage)            │
        │  ├─ /browser (in-app browser)       │
        │  ├─ /v2-results (search results)    │
        │  ├─ /v2-images (image search)       │
        │  ├─ /v2-videos (video search)       │
        │  ├─ /v2-news (news results)         │
        │  ├─ /v2-settings (settings)         │
        │  └─ /v2-history (browser history)   │
        └──────────────────────────┬───────────┘
                                   │
                    ┌──────────────┴──────────────┐
                    ↓                             ↓
        ┌─────────────────────┐    ┌──────────────────────┐
        │   Search Backend    │    │  Crawler Backend     │
        │  (search.js)        │    │  (crawler.js)        │
        │  (ranker.js)        │    │  (parser.js)         │
        │  (database.js)      │    │  (robots.js)         │
        └────────────┬────────┘    └──────────────────────┘
                     │
                     ↓
        ┌─────────────────────────────┐
        │   SQLite Index             │
        │  (data/novasearch.db)       │
        │  - pages table              │
        │  - FTS5 index               │
        │  - images table (V2.4)      │
        │  - videos table (V2.5)      │
        │  - news table (V2.6)        │
        └─────────────────────────────┘
```

---

## STAGE 1: Browser UI + Tabs ✅ COMPLETE

### Files Created

```
public/
├── v2-index.html      (New homepage)
├── v2-styles.css      (Unified styles)
├── v2-app.js          (Homepage logic)
├── browser.html       (In-app browser)
└── v2-browser.js      (Tab management)

android/
├── MainActivity.kt    (Android WebView app)
└── AndroidManifest.xml (App configuration)

server/
└── server.js          (Updated with V2 routes)
```

### Features Implemented

1. **Homepage** (`/v2-index`)
   - Search/address bar
   - Search categories (All, Images, Videos, News, Maps)
   - Shortcuts grid (add/edit/remove)
   - Recently visited pages
   - Search suggestions
   - Three-dot menu
   - Theme toggle (dark/light)

2. **In-App Browser** (`/browser`)
   - Tab system (create, switch, close, duplicate)
   - Navigation buttons (back, forward, reload, home)
   - URL/address bar
   - Loading progress bar
   - Error page handling
   - Favicon support (basic)
   - iframe-based webpage display

3. **Data Persistence**
   - Shortcuts saved to localStorage
   - Search history saved to localStorage
   - Browser history saved to localStorage
   - All data survives server restart

4. **Android WebView**
   - Safe URL scheme blocking (file://, javascript:, data:)
   - External link routing to system browser
   - Android back button integration
   - Local server connection (localhost:3000)

### How to Use STAGE 1

1. **Start the server**
   ```bash
   cd NovaSearch
   npm start
   ```

2. **Open in browser**
   ```
   http://localhost:3000
   ```

3. **Test homepage**
   - Search something
   - Add a shortcut
   - Click a shortcut (opens in browser)
   - Create multiple browser tabs
   - Navigate back/forward

4. **Build Android app** (Android Studio project)
   - Add MainActivity.kt to your Android project
   - Add AndroidManifest.xml
   - Point WebView to http://localhost:3000
   - Build and run on device/emulator

---

## STAGE 2: Improved Search Results (Ready for Implementation)

### Files to Create/Update

```
public/
├── v2-results.js      (Enhanced results logic)
└── v2-styles.css      (Update with result styling)
```

### Planned Features

- Result numbering
- Better snippet generation
- Favicon display for results
- Three-dot menu per result:
  - Open
  - Open in new tab
  - Copy link
  - Add shortcut
  - Open externally
- Result metadata (domain, last crawled)
- Performance indicators

---

## STAGE 3: Shortcuts + History + Menus (Ready)

### Additions to Implement

- Edit shortcut modal
- Reorder shortcuts (drag-drop)
- Delete individual shortcuts
- Manage shortcuts page
- Full search history page
- Full browser history page
- Clear history options
- Three-dot context menus for tabs
- Three-dot context menus for results

---

## STAGE 4: Image Indexing (Design Phase)

### Backend

1. **New module: `server/images.js`**
   - Extract images from crawled pages
   - Store: image URL, source page, alt text, title, domain
   - Create images table in database

2. **Database schema**
   ```sql
   CREATE TABLE images (
     id INTEGER PRIMARY KEY,
     url TEXT UNIQUE,
     source_page_url TEXT,
     alt_text TEXT,
     title TEXT,
     domain TEXT,
     crawled_at TEXT
   );
   ```

3. **New API endpoint**
   ```
   GET /api/images?q=QUERY&page=1
   ```

### Frontend

1. **New page: `public/v2-images.html`**
   - Responsive image grid
   - Click to view image details
   - Context menu: open, open externally, copy link

2. **Image viewer modal**
   - Full-size image
   - Alt text
   - Source page link
   - Domain info

---

## STAGE 5: Video Indexing (Design Phase)

### Backend

1. **New module: `server/videos.js`**
   - Detect video references (YouTube embeds, links, etc.)
   - Store: video URL, title, thumbnail URL, description, source page, domain
   - Do NOT download/rehost videos

2. **Database schema**
   ```sql
   CREATE TABLE videos (
     id INTEGER PRIMARY KEY,
     url TEXT UNIQUE,
     title TEXT,
     thumbnail_url TEXT,
     description TEXT,
     source_page_url TEXT,
     domain TEXT,
     crawled_at TEXT
   );
   ```

3. **New API endpoint**
   ```
   GET /api/videos?q=QUERY&page=1
   ```

### Frontend

1. **New page: `public/v2-videos.html`**
   - Video cards with thumbnails
   - Click to open in system player
   - Respect copyright (link, don't embed)

---

## STAGE 6: News Results (Design Phase)

### Backend

1. **New module: `server/news.js`**
   - Detect news-style pages (has publish date, source, body text)
   - Extract: title, source, published date, snippet, thumbnail
   - Only mark a page as "news" if evidence supports it

2. **Database schema**
   ```sql
   CREATE TABLE news (
     id INTEGER PRIMARY KEY,
     url TEXT UNIQUE,
     title TEXT,
     source_domain TEXT,
     published_at TEXT,
     snippet TEXT,
     thumbnail_url TEXT,
     body_text TEXT,
     crawled_at TEXT
   );
   ```

### Frontend

1. **News results page**
   - Timeline-style layout
   - Source badge
   - Published date
   - Snippet
   - Thumbnail if available

---

## STAGE 7: Maps Integration (Design Phase)

### Implementation

1. **No fake map**
   - Detect location-related queries
   - Use Android Intent to open:
     ```kotlin
     geo:0,0?q=restaurants+near+me
     ```
   - Fallback: Show available map apps on device

2. **Graceful fallback**
   - If no map app installed, show message:
     ```
     "No map application found.
      Install Google Maps or another mapping app."
     ```

---

## STAGE 8: AI Overview (Design Phase)

### Architecture

1. **New module: `server/ai.js`**
   - Abstract layer for AI providers
   - Configurable backend:
     - Local model (future)
     - OpenAI (optional)
     - Ollama (optional)
     - None (default)

2. **Default behavior**
   - If no AI configured, show:
     ```
     "AI answers unavailable.
      Search results still available."
     ```

3. **Implementation**
   ```javascript
   // server/ai.js
   class AIProvider {
     async generateOverview(query, documents) {
       if (!this.configured()) {
         return null;
       }
       // Generate answer from documents
     }
   }
   ```

4. **Safe answer generation**
   - Use only indexed documents
   - Cite sources
   - Avoid hallucinations
   - Indicate uncertainty
   - No fake citations

---

## STAGE 9: Security + Performance (Final)

### Security Checklist

- ✅ URL scheme validation (file://, javascript:, data:)
- ✅ XSS prevention (escape HTML)
- ✅ CSRF protection (headers)
- ✅ Crawl limits enforced
- ✅ Request timeouts set
- ✅ Response size limits
- ✅ robots.txt respected
- ✅ Safe WebView configuration
- ✅ No executable uploads
- ⏳ HTTPS redirect support
- ⏳ Content Security Policy headers

### Performance Optimization

- Image lazy-loading
- Search result pagination
- Index compression
- Mobile network optimization
- Minimize JavaScript bundle size
- Cache frequently accessed pages

---

## Testing After Each Stage

After each stage, run these tests:

1. **Search indexing**
   ```bash
   npm start
   # Crawl a website
   # Search for terms
   # Verify results
   ```

2. **Browser tabs**
   ```
   Open /browser
   Create 3 tabs
   Navigate around
   Test back/forward
   ```

3. **Persistence**
   ```
   Add shortcuts
   Restart server
   Verify shortcuts still there
   ```

4. **Android**
   ```
   Build and deploy to device
   Test all features
   Test back button
   Test external links
   ```

---

## Technology Stack

### Backend
- **Node.js** + **Express**
- **SQLite** (no better-sqlite3, use built-in or simple wrapper)
- **Cheerio** (HTML parsing)
- **Axios** (HTTP requests)

### Frontend
- **HTML5** + **CSS3** (no framework)
- **Vanilla JavaScript** (no framework)
- **localStorage** (data persistence)

### Android
- **Kotlin** (MainActivity)
- **WebView** (rendering)
- **Android Intent** (external links)

---

## Development Checklist

### STAGE 1 ✅
- [x] Browser-style homepage created
- [x] In-app browser with tabs implemented
- [x] Android WebView shell created
- [x] Shortcuts management working
- [x] Search suggestions working
- [x] Recently visited tracking working
- [x] Dark/light theme toggle working
- [x] Server routes added for all pages
- [x] V1 functionality preserved

### STAGE 2 (Ready)
- [ ] Result numbering implemented
- [ ] Better snippet generation
- [ ] Favicon display for results
- [ ] Three-dot menu per result
- [ ] Result metadata shown
- [ ] Performance indicators

### STAGE 3 (Ready)
- [ ] Shortcut editing modal
- [ ] Shortcut reordering
- [ ] Shortcut deletion
- [ ] Manage shortcuts page
- [ ] Full history pages
- [ ] Context menus for tabs/results

### STAGE 4-9
- [ ] Image indexing + search
- [ ] Video indexing + search
- [ ] News detection + results
- [ ] Maps integration
- [ ] AI overview layer
- [ ] Security hardening
- [ ] Performance tuning

---

## Running NovaSearch V2

### Termux / Linux

```bash
cd NovaSearch
npm install
npm start
# http://localhost:3000
```

### Android (WebView App)

1. Create Android project in Android Studio
2. Copy MainActivity.kt and AndroidManifest.xml
3. Build and deploy to device
4. App connects to localhost:3000

### First Crawl

1. Open http://localhost:3000/admin
2. Enter seed URL (e.g., https://example.com)
3. Set max pages to 20
4. Start crawl
5. Go back to home page
6. Search for terms
7. Results appear in browser

---

## Notes

- **V1 Preserved**: All original V1 functionality remains intact. V2 is an upgrade layer.
- **Lightweight**: No heavy frameworks (React, Vue). Vanilla JavaScript and CSS.
- **Offline-first**: Local storage + SQLite mean everything works offline (after initial crawl).
- **Mobile-first**: Designed for Android phones and Termux from the start.
- **Extensible**: AI layer, plugin system, and multi-provider support can be added in future versions.

---

## Next Steps

1. **Test STAGE 1 thoroughly**
   - Crawl a real website
   - Search within NovaSearch
   - Create/delete/edit shortcuts
   - Open browser tabs
   - Navigate with back/forward

2. **Plan STAGE 2** (improved results)
   - Wire up v2-results.js
   - Add result numbering, snippets, menus

3. **Build Android app** (if targeting mobile)
   - Use Android Studio
   - Add MainActivity.kt
   - Point WebView to localhost:3000
   - Test on device

4. **Continue through stages** (image → video → news → maps → AI)

---

## Questions?

Refer to the main README.md for architecture overview.
Refer to server/ and public/ source files for implementation details.
