package com.novasearch.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.Menu
import android.view.MenuItem
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

/**
 * NovaSearch Android WebView Application
 *
 * This shell wraps the NovaSearch web app (running on localhost:3000)
 * in a native Android WebView for a true mobile experience.
 *
 * Features:
 * - In-app browser with tabs (handled by web frontend)
 * - Safe navigation (blocks file://, javascript:, data: schemes)
 * - Android back button integration
 * - Local server connection
 * - External link handling
 */

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private val SERVER_URL = "http://localhost:3000"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        setupWebView()

        // Load the homepage
        webView.loadUrl(SERVER_URL)
    }

    private fun setupWebView() {
        val settings = webView.settings

        // JavaScript is required for NovaSearch to work
        settings.javaScriptEnabled = true

        // Security settings
        settings.allowFileAccess = false // Block file:// access
        settings.allowContentAccess = false

        // Network settings
        settings.databaseEnabled = true
        settings.domStorageEnabled = true
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true

        // User agent (identify as NovaSearch Android)
        settings.userAgentString = "NovaSearchAndroid/2.0"

        // Setup web clients
        webView.webViewClient = NovaSearchWebViewClient(this)
        webView.webChromeClient = WebChromeClient()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        // Back button handling
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (webView.canGoBack()) {
                webView.goBack()
                return true
            } else {
                finish()
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        // Reload button in menu
        menu?.add("Reload").setOnMenuItemClickListener {
            webView.reload()
            true
        }
        return true
    }

    /**
     * Custom WebViewClient to handle navigation safely
     */
    private class NovaSearchWebViewClient(val activity: Activity) : WebViewClient() {

        override fun shouldOverrideUrlLoading(
            view: WebView?,
            request: WebResourceRequest?
        ): Boolean {
            val url = request?.url?.toString() ?: return false

            // Allow localhost
            if (url.startsWith("http://localhost:3000") || 
                url.startsWith("http://127.0.0.1:3000")) {
                return false
            }

            // Block dangerous schemes
            if (url.startsWith("javascript:") || 
                url.startsWith("data:") || 
                url.startsWith("file:")) {
                return true
            }

            // Open external links in system browser
            if (url.startsWith("http://") || url.startsWith("https://")) {
                try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                    activity.startActivity(intent)
                    return true
                } catch (e: Exception) {
                    return true
                }
            }

            // Handle Android intents (maps, etc.)
            return try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                activity.startActivity(intent)
                true
            } catch (e: Exception) {
                false
            }
        }

        override fun onReceivedError(
            view: WebView?,
            request: WebResourceRequest?,
            error: WebResourceError?
        ) {
            super.onReceivedError(view, request, error)
            
            val url = request?.url?.toString() ?: "unknown"
            val description = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                error?.description.toString()
            } else {
                "Unknown error"
            }

            // Log errors for debugging
            android.util.Log.e("NovaSearch", "WebView error: $url - $description")
        }
    }
}
