# 🔍 NovaSearch

A real, self-hosted search engine. NovaSearch crawls websites you specify, builds a local full-text index (JSON local index), ranks results with a BM25-inspired algorithm, and serves searches — with no external APIs, no API keys, and no fake results.

---

## Architecture

```
Seed URL → Crawler → HTML Parser → JSON local index Index → Search API → Ranked Results
```

| Layer | Tech |
|---|---|
| Backend | Node.js + Express |
| Crawler | Axios + Cheerio |
| Index | JSON local index (porter stemmer) |
| Ranking | BM25 + field weights + phrase match |
| Frontend | Vanilla HTML/CSS/JS |

---

## Quick Start

### 1. Install dependencies

```bash
cd novasearch
npm install
```

> **Note:** This Termux edition uses a pure-JavaScript JSON index and does not require native database addons.
> - **macOS:** Xcode Command Line Tools (`xcode-select --install`)
> - **Ubuntu/Debian:** `sudo apt install build-essential python3`
> - **Windows:** `npm install --global windows-build-tools` (run as admin)

### 2. Start NovaSearch

```bash
npm start
```

The server starts at **http://localhost:3000**

### 3. Open the admin crawler

Visit **http://localhost:3000/admin**

---

## Using NovaSearch

### Add and crawl your first website

1. Go to **http://localhost:3000/admin**
2. Enter a seed URL, e.g. `https://en.wikipedia.org/wiki/Python_(programming_language)`
3. Set **Max Pages** (e.g. `30`) and **Max Depth** (e.g. `1`)
4. Leave **Same-domain only** checked for a focused crawl
5. Click **▶ Start Crawl**
6. Watch the stats update live — crawled, skipped, errors, indexed count
7. When the status shows **Finished**, your pages are in the index

### Search the indexed pages

1. Go to **http://localhost:3000**
2. Type a query and press **Enter** or click **Search**
3. Results are ranked by BM25 relevance + phrase matching + field weights

### Add more websites

Repeat the crawl steps with a new seed URL. Pages accumulate in the index across multiple crawls.

### Change crawl limits

On the admin page, adjust **Max Pages** (1–500) and **Max Depth** (0–10) before each crawl:

| Depth | Meaning |
|---|---|
| 0 | Only the seed URL itself |
| 1 | Seed + links found on seed |
| 2 | Seed + 2 levels of links (recommended) |
| 3+ | Deep crawl — use a low page limit |

### Reset / clear the index

On the admin page click **🗑 Reset Index**. This wipes all indexed pages and crawl history. The database file is recreated automatically on next crawl.

---

## API Reference

### Search

```
GET /api/search?q=QUERY&page=1
```

Response:
```json
{
  "query": "python programming",
  "total": 12,
  "page": 1,
  "totalPages": 2,
  "searchTime": "14ms",
  "results": [
    {
      "title": "Python (programming language) - Wikipedia",
      "url": "https://en.wikipedia.org/wiki/Python_(programming_language)",
      "description": "Python is a high-level, general-purpose programming language…",
      "domain": "en.wikipedia.org",
      "score": 1.0,
      "crawledAt": "2024-01-15T12:00:00.000Z"
    }
  ]
}
```

### Start crawl

```
POST /api/crawl
Content-Type: application/json

{
  "url": "https://example.com",
  "maxPages": 50,
  "maxDepth": 2,
  "sameDomain": true
}
```

### Stop crawl

```
POST /api/crawl/stop
```

### Crawl status

```
GET /api/crawl/status
```

### Global stats

```
GET /api/stats
```

### Indexed pages (paginated)

```
GET /api/admin/pages?limit=20&offset=0
```

### Reset database

```
POST /api/admin/reset
```

---

## Ranking Algorithm

Results are scored by `server/ranker.js` using multiple signals:

| Signal | Weight |
|---|---|
| Title (BM25) | 10× |
| Headings (BM25) | 6× |
| Description (BM25) | 5× |
| URL keyword match | 3× |
| Body text (BM25) | 1× |
| Exact/phrase title match | ×3 bonus |
| local index base score | ×0.5 bonus |
| Query term coverage | Up to +5 |

Scores are normalized to 0–1 and displayed on each result.

---

## Crawler Behaviour

- Respects **robots.txt** (fetched once per domain per hour)
- User-Agent: `NovaSearchBot/1.0 (+http://localhost:3000/bot)`
- Rate-limits requests per domain (600 ms gap minimum)
- Skips binary files (images, PDFs, fonts, archives, …)
- Skips pages returning non-HTML content types
- Max response body: 4 MB per page
- Max redirects: 5
- Request timeout: 12 seconds
- Max concurrency: 3 simultaneous fetches
- Never follows `javascript:` or `mailto:` links
- Same-domain mode prevents crawling external sites

---

## Project Structure

```
novasearch/
├── server/
│   ├── server.js       — Express app, all API routes
│   ├── crawler.js      — Web crawler (queue, rate-limiting, robots.txt)
│   ├── parser.js       — HTML → structured fields (Cheerio)
│   ├── database.js     — SQLite init, local index table + triggers
│   ├── search.js       — local index query + fallback LIKE search
│   ├── ranker.js       — BM25 + multi-field ranking
│   ├── robots.js       — robots.txt fetch + cache
│   └── url-utils.js    — URL normalization, validation, filtering
│
├── public/
│   ├── index.html      — Homepage
│   ├── results.html    — Search results page
│   ├── admin.html      — Admin / crawler dashboard
│   ├── styles.css      — Full UI stylesheet (dark + light)
│   ├── app.js          — Homepage JS
│   ├── results.js      — Results page JS
│   └── admin.js        — Admin page JS
│
├── data/
│   └── novasearch.db   — JSON index (auto-created)
│
├── package.json
├── .gitignore
└── README.md
```

---

## Good Seed URLs to Start With

| Site | Suggested settings |
|---|---|
| `https://en.wikipedia.org/wiki/TOPIC` | depth 1, 30–50 pages |
| `https://docs.python.org/3/` | depth 2, 100 pages |
| `https://nodejs.org/en/docs/` | depth 2, 50 pages |
| Your own site | depth 3, 200 pages |

---

## Recent Improvements

**v1.1 fixes:**
- ✅ **Concurrency architecture**: Crawler now serializes requests per-domain while maintaining up to 3 simultaneous domain fetches. This ensures the 600ms per-domain rate-limiting is honored without race conditions.
- ✅ **Content deduplication**: Pages are now checked against a SHA-256 hash of their extracted content. If the hash hasn't changed on a re-crawl, the index entry is left as-is (no unnecessary updates).
- ⚠️ **Queue persistence**: Crawl queues are in-memory. If the server crashes mid-crawl, the queue is lost. A future version could persist to `crawl_queue` table.

## Known Limitations

### 1. JavaScript-rendered content

NovaSearch uses Cheerio to parse raw HTML. If a website renders most of its content with JavaScript after the page loads, NovaSearch will only see the initial HTML skeleton.

**Example:** A React SPA that renders the page client-side will appear nearly empty.

**Future solution:** Use Playwright or Puppeteer to run JavaScript before indexing.

### 2. Ranking on limited result set

The ranking algorithm (BM25 + field weights + phrase match) runs on the top 200 local index results, then ranks those 200.

**Why:** Computing full BM25 over millions of documents for every query is expensive.

**Reality:** Large search engines store precomputed statistics (IDF, document frequency) and rank the entire index. NovaSearch recalculates on each query.

**Acceptable for:** Smaller indexes (< 100k pages).

### 3. No queue persistence

Crawl queue lives in memory. Server crash = queue lost.

**Future fix:** Store queue in `crawl_queue` table, resume on restart.

### 4. Rate-limiting simplified

NovaSearch uses a 600ms gap between requests to the same domain. No backoff, no respect for `Crawl-Delay` or `Request-Rate` in robots.txt.

### 5. No image/PDF extraction

Only HTML pages are indexed. PDF metadata, images, documents, and media are skipped.

---

## Development

```bash
npm run dev   # uses nodemon for auto-reload
```

The database is preserved between restarts. Use the admin Reset button to clear it.
