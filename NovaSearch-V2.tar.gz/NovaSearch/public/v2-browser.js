'use strict';

// ── Tab Manager ──────────────────────────────────────────────────────────

class TabManager {
  constructor() {
    this.tabs = [];
    this.activeTabId = null;
    this.nextTabId = 1;
    this.BROWSER_HISTORY_KEY = 'nova-browser-history';
  }

  createTab(url = null) {
    const tabId = this.nextTabId++;
    const tab = {
      id: tabId,
      url: url || 'about:blank',
      title: 'New Tab',
      favicon: null,
      history: url ? [url] : [],
      historyIndex: url ? 0 : -1,
    };
    this.tabs.push(tab);
    this.setActiveTab(tabId);
    return tabId;
  }

  setActiveTab(tabId) {
    this.activeTabId = tabId;
    this.renderTabs();
    this.loadTabContent();
  }

  getActiveTab() {
    return this.tabs.find(t => t.id === this.activeTabId) || this.tabs[0];
  }

  closeTab(tabId) {
    this.tabs = this.tabs.filter(t => t.id !== tabId);
    if (this.activeTabId === tabId) {
      this.activeTabId = this.tabs.length > 0 ? this.tabs[this.tabs.length - 1].id : null;
    }
    if (this.tabs.length === 0) {
      this.createTab();
    }
    this.renderTabs();
    this.loadTabContent();
  }

  duplicateTab(tabId) {
    const tab = this.tabs.find(t => t.id === tabId);
    if (tab) {
      this.createTab(tab.url);
    }
  }

  reloadTab(tabId = null) {
    const tab = tabId ? this.tabs.find(t => t.id === tabId) : this.getActiveTab();
    if (tab) {
      this.loadTabContent(tab.id);
    }
  }

  navigateBack(tabId = null) {
    const tab = tabId ? this.tabs.find(t => t.id === tabId) : this.getActiveTab();
    if (tab && tab.historyIndex > 0) {
      tab.historyIndex--;
      this.loadTabContent(tab.id);
    }
  }

  navigateForward(tabId = null) {
    const tab = tabId ? this.tabs.find(t => t.id === tabId) : this.getActiveTab();
    if (tab && tab.historyIndex < tab.history.length - 1) {
      tab.historyIndex++;
      this.loadTabContent(tab.id);
    }
  }

  navigateToUrl(url, tabId = null) {
    const tab = tabId ? this.tabs.find(t => t.id === tabId) : this.getActiveTab();
    if (!tab) return;

    // Validate URL
    if (!this.isValidUrl(url)) {
      // Try as search query
      url = '/v2-results?q=' + encodeURIComponent(url);
    }

    // Add to history
    tab.history = tab.history.slice(0, tab.historyIndex + 1);
    tab.history.push(url);
    tab.historyIndex = tab.history.length - 1;

    this.loadTabContent(tab.id);
  }

  isValidUrl(str) {
    try {
      const url = new URL(str);
      return ['http:', 'https:', 'about:'].includes(url.protocol);
    } catch {
      return false;
    }
  }

  loadTabContent(tabId = null) {
    const tab = tabId ? this.tabs.find(t => t.id === tabId) : this.getActiveTab();
    if (!tab) return;

    const iframe = document.getElementById('webpageIframe');
    const urlInput = document.getElementById('urlInput');

    // Show loading bar
    const progress = document.getElementById('progressBar');
    progress.style.display = 'block';
    progress.style.width = '30%';

    setTimeout(() => {
      try {
        iframe.src = tab.url;
        urlInput.value = tab.url;
        updateNavButtons();
      } catch (e) {
        console.error('Load error:', e);
        showError('Could not load URL', 'The page is not accessible.');
        progress.style.display = 'none';
      }
    }, 100);

    setTimeout(() => {
      progress.style.width = '100%';
      setTimeout(() => progress.style.display = 'none', 300);
    }, 1500);
  }

  updateTabTitle(tabId, title) {
    const tab = this.tabs.find(t => t.id === tabId);
    if (tab) {
      tab.title = title || 'Page';
      this.renderTabs();
      this.recordBrowserHistory(tab.url, tab.title);
    }
  }

  recordBrowserHistory(url, title) {
    const history = JSON.parse(localStorage.getItem(this.BROWSER_HISTORY_KEY) || '[]');
    history.unshift({ url, title, time: Date.now() });
    history.splice(50); // Keep last 50
    localStorage.setItem(this.BROWSER_HISTORY_KEY, JSON.stringify(history));
  }

  renderTabs() {
    const tabBar = document.getElementById('tabBar');
    let html = '<button class="v2-tab-btn v2-add-tab-btn" id="newTabBtn" title="New tab">+</button>';

    for (const tab of this.tabs) {
      const isActive = tab.id === this.activeTabId ? 'active' : '';
      const favicon = tab.favicon ? `<img src="${tab.favicon}" class="v2-tab-favicon">` : '◆';
      html += `
        <div class="v2-tab-btn ${isActive}" data-tab-id="${tab.id}" onclick="tabManager.setActiveTab(${tab.id})">
          ${favicon}
          <span>${escapeHtml(tab.title.slice(0, 20))}</span>
          <div class="v2-tab-close" onclick="event.stopPropagation(); tabManager.closeTab(${tab.id})">✕</div>
        </div>
      `;
    }

    // Clear and rebuild
    tabBar.innerHTML = html;
    document.getElementById('newTabBtn').addEventListener('click', () => {
      tabManager.createTab();
    });

    // Make tab bar scrollable to active tab
    const activeTabEl = tabBar.querySelector('.v2-tab-btn.active');
    if (activeTabEl) {
      activeTabEl.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
    }
  }
}

// ── Global instance ──────────────────────────────────────────────────────

const tabManager = new TabManager();

// ── URL Input ────────────────────────────────────────────────────────────

const urlInput = document.getElementById('urlInput');

urlInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    const url = urlInput.value.trim();
    if (url) {
      tabManager.navigateToUrl(url);
    }
  }
});

// ── Navigation Buttons ───────────────────────────────────────────────────

document.getElementById('backBtn').addEventListener('click', () => {
  tabManager.navigateBack();
});

document.getElementById('forwardBtn').addEventListener('click', () => {
  tabManager.navigateForward();
});

document.getElementById('reloadBtn').addEventListener('click', () => {
  tabManager.reloadTab();
});

document.getElementById('homeBtn').addEventListener('click', () => {
  window.location.href = '/v2-index';
});

document.getElementById('menuBtn').addEventListener('click', (e) => {
  const menu = document.getElementById('resultContextMenu');
  menu.style.position = 'fixed';
  menu.style.top = e.target.getBoundingClientRect().bottom + 8 + 'px';
  menu.style.right = '12px';
  menu.style.display = menu.style.display === 'none' ? 'block' : 'none';
});

function updateNavButtons() {
  const tab = tabManager.getActiveTab();
  document.getElementById('backBtn').disabled = !tab || tab.historyIndex <= 0;
  document.getElementById('forwardBtn').disabled = !tab || tab.historyIndex >= tab.history.length - 1;
}

// ── Iframe Communication ─────────────────────────────────────────────────

const iframe = document.getElementById('webpageIframe');

iframe.addEventListener('load', () => {
  try {
    const doc = iframe.contentDocument || iframe.contentWindow.document;
    const title = doc.title || 'Page';
    const tab = tabManager.getActiveTab();
    if (tab) {
      tabManager.updateTabTitle(tab.id, title);
    }
  } catch (e) {
    // Cross-origin or other error - can't access title
  }
  updateNavButtons();
});

iframe.addEventListener('error', () => {
  showError('Page failed to load', 'Check the URL and try again.');
});

// ── Error Handler ────────────────────────────────────────────────────────

function showError(title, message) {
  const errorPage = document.getElementById('errorPage');
  document.getElementById('errorTitle').textContent = title;
  document.getElementById('errorMessage').textContent = message;
  errorPage.style.display = 'flex';
  document.getElementById('browserContent').style.display = 'none';
}

function hideError() {
  document.getElementById('errorPage').style.display = 'none';
  document.getElementById('browserContent').style.display = 'block';
}

// ── Context Menus ────────────────────────────────────────────────────────

document.addEventListener('click', (e) => {
  // Close menus on click outside
  if (!e.target.closest('#menuBtn')) {
    document.getElementById('resultContextMenu').style.display = 'none';
  }
});

// ── Initialization ───────────────────────────────────────────────────────

function init() {
  // Get initial URL from query param
  const params = new URLSearchParams(window.location.search);
  const initialUrl = params.get('url') || 'about:blank';

  // Create first tab
  tabManager.createTab(initialUrl);
  updateNavButtons();
}

document.addEventListener('DOMContentLoaded', init);

// ── Utilities ────────────────────────────────────────────────────────────

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}
