'use strict';

// ── Theme ────────────────────────────────────────────────────────────────

const THEME_KEY = 'nova-theme';
const SHORTCUTS_KEY = 'nova-shortcuts';
const SEARCH_HISTORY_KEY = 'nova-search-history';
const BROWSER_HISTORY_KEY = 'nova-browser-history';

function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  document.getElementById('themeToggle').textContent = theme === 'dark' ? '☀️' : '🌙';
}

function initTheme() {
  const saved = localStorage.getItem(THEME_KEY);
  const preferred = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  applyTheme(saved || preferred);
}

document.getElementById('themeToggle').addEventListener('click', () => {
  const current = document.documentElement.getAttribute('data-theme');
  const next = current === 'dark' ? 'light' : 'dark';
  applyTheme(next);
  localStorage.setItem(THEME_KEY, next);
});

initTheme();

// ── Shortcuts ────────────────────────────────────────────────────────────

let shortcuts = [];

function loadShortcuts() {
  const saved = localStorage.getItem(SHORTCUTS_KEY);
  shortcuts = saved ? JSON.parse(saved) : [
    { id: 1, name: 'Wikipedia', url: 'https://wikipedia.org', icon: '📚' },
    { id: 2, name: 'GitHub', url: 'https://github.com', icon: '💻' },
    { id: 3, name: 'YouTube', url: 'https://youtube.com', icon: '▶️' },
  ];
  renderShortcuts();
}

function saveShortcuts() {
  localStorage.setItem(SHORTCUTS_KEY, JSON.stringify(shortcuts));
}

function renderShortcuts() {
  const grid = document.getElementById('shortcutsGrid');
  grid.innerHTML = shortcuts.map(s => `
    <div class="v2-shortcut-card" data-id="${s.id}" onclick="openShortcut(${s.id})">
      <div class="v2-shortcut-icon">${s.icon}</div>
      <div class="v2-shortcut-name">${escapeHtml(s.name)}</div>
      <div class="v2-shortcut-menu" onclick="event.stopPropagation(); showShortcutMenu(${s.id}, event)">⋮</div>
    </div>
  `).join('');
}

function openShortcut(id) {
  const shortcut = shortcuts.find(s => s.id === id);
  if (shortcut) {
    // Navigate to browser with this URL
    window.location.href = `/browser?url=${encodeURIComponent(shortcut.url)}`;
  }
}

function showShortcutMenu(id, event) {
  const menu = document.createElement('div');
  menu.className = 'v2-menu-popup';
  menu.style.position = 'fixed';
  menu.style.top = event.clientY + 'px';
  menu.style.left = Math.max(20, event.clientX - 140) + 'px';
  menu.innerHTML = `
    <div class="v2-menu-content">
      <div class="v2-menu-item" onclick="editShortcut(${id})">✏️ Edit</div>
      <div class="v2-menu-item" onclick="removeShortcut(${id})">🗑️ Remove</div>
    </div>
  `;
  document.body.appendChild(menu);
  setTimeout(() => menu.remove(), 5000); // Auto-remove
}

function removeShortcut(id) {
  shortcuts = shortcuts.filter(s => s.id !== id);
  saveShortcuts();
  renderShortcuts();
}

function editShortcut(id) {
  const shortcut = shortcuts.find(s => s.id === id);
  if (shortcut) {
    document.getElementById('shortcutUrl').value = shortcut.url;
    document.getElementById('shortcutName').value = shortcut.name;
    document.getElementById('shortcutIcon').value = shortcut.icon;
    // Set editing flag
    window._editingShortcutId = id;
    document.getElementById('shortcutModal').style.display = 'flex';
  }
}

// ── Shortcut Modal ───────────────────────────────────────────────────────

document.getElementById('addShortcutBtn').addEventListener('click', () => {
  window._editingShortcutId = null;
  document.getElementById('shortcutUrl').value = '';
  document.getElementById('shortcutName').value = '';
  document.getElementById('shortcutIcon').value = '🌐';
  document.getElementById('shortcutModal').style.display = 'flex';
});

document.getElementById('closeShortcutModal').addEventListener('click', () => {
  document.getElementById('shortcutModal').style.display = 'none';
});

document.getElementById('cancelShortcutBtn').addEventListener('click', () => {
  document.getElementById('shortcutModal').style.display = 'none';
});

document.getElementById('saveShortcutBtn').addEventListener('click', () => {
  const url = document.getElementById('shortcutUrl').value.trim();
  const name = document.getElementById('shortcutName').value.trim();
  const icon = document.getElementById('shortcutIcon').value.trim() || '🌐';

  if (!url || !name) {
    alert('Please fill in URL and name.');
    return;
  }

  if (!url.startsWith('http://') && !url.startsWith('https://')) {
    alert('URL must start with http:// or https://');
    return;
  }

  if (window._editingShortcutId) {
    // Edit existing
    const s = shortcuts.find(x => x.id === window._editingShortcutId);
    if (s) {
      s.url = url;
      s.name = name;
      s.icon = icon;
    }
  } else {
    // Add new
    shortcuts.push({
      id: Date.now(),
      url,
      name,
      icon,
    });
  }

  saveShortcuts();
  renderShortcuts();
  document.getElementById('shortcutModal').style.display = 'none';
});

// ── Search ───────────────────────────────────────────────────────────────

const searchInput = document.getElementById('homeSearchInput');
const categoryBtns = document.querySelectorAll('.v2-category-btn');
let currentCategory = 'all';

categoryBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    categoryBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentCategory = btn.dataset.category;
  });
});

function performSearch() {
  const query = searchInput.value.trim();
  if (!query) return;

  // Save to search history
  const history = JSON.parse(localStorage.getItem(SEARCH_HISTORY_KEY) || '[]');
  if (!history.includes(query)) {
    history.unshift(query);
    history.splice(10); // Keep last 10
    localStorage.setItem(SEARCH_HISTORY_KEY, JSON.stringify(history));
  }

  // Navigate to results or specific category
  const categoryPath = currentCategory === 'all' ? 'results' : currentCategory;
  window.location.href = `/v2-results?q=${encodeURIComponent(query)}&cat=${currentCategory}`;
}

searchInput.addEventListener('keydown', e => {
  if (e.key === 'Enter') performSearch();
  if (e.key === 'Escape') {
    searchInput.blur();
    document.getElementById('suggestionsPopup').style.display = 'none';
  }
});

searchInput.addEventListener('input', () => {
  const query = searchInput.value.trim();
  if (query.length < 2) {
    document.getElementById('suggestionsPopup').style.display = 'none';
    return;
  }

  // Generate suggestions from history + common terms
  const suggestions = getSuggestions(query);
  if (suggestions.length > 0) {
    showSuggestions(suggestions);
  }
});

function getSuggestions(query) {
  const history = JSON.parse(localStorage.getItem(SEARCH_HISTORY_KEY) || '[]');
  const matching = history.filter(h => h.toLowerCase().includes(query.toLowerCase()));
  return matching.slice(0, 5);
}

function showSuggestions(suggestions) {
  const list = document.getElementById('suggestionsList');
  list.innerHTML = suggestions.map(s => `
    <div class="v2-suggestion-item" onclick="searchFor('${escapeHtml(s)}')">${escapeHtml(s)}</div>
  `).join('');
  document.getElementById('suggestionsPopup').style.display = 'block';
}

function searchFor(query) {
  searchInput.value = query;
  performSearch();
}

// ── Recently Visited ─────────────────────────────────────────────────────

function loadRecentlyVisited() {
  const history = JSON.parse(localStorage.getItem(BROWSER_HISTORY_KEY) || '[]');
  if (history.length === 0) {
    document.getElementById('recentSection').style.display = 'none';
    return;
  }

  const recent = history.slice(0, 5);
  const list = document.getElementById('recentList');
  list.innerHTML = recent.map(h => `
    <div class="v2-recent-item" onclick="openPage('${escapeHtml(h.url)}')">
      <div class="v2-recent-info">
        <div class="v2-recent-title">${escapeHtml(h.title || h.url)}</div>
        <div class="v2-recent-url">${escapeHtml(h.url)}</div>
      </div>
      <div class="v2-recent-time">${getTimeAgo(h.time)}</div>
    </div>
  `).join('');
  document.getElementById('recentSection').style.display = 'block';
}

function openPage(url) {
  window.location.href = `/browser?url=${encodeURIComponent(url)}`;
}

function getTimeAgo(timestamp) {
  const diff = Date.now() - timestamp;
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return mins + 'm ago';
  const hours = Math.floor(mins / 60);
  if (hours < 24) return hours + 'h ago';
  const days = Math.floor(hours / 24);
  return days + 'd ago';
}

// ── Home Menu ────────────────────────────────────────────────────────────

document.getElementById('homeMenuBtn').addEventListener('click', (e) => {
  const popup = document.getElementById('homeMenuPopup');
  popup.style.display = popup.style.display === 'none' ? 'block' : 'none';
  popup.style.top = e.target.getBoundingClientRect().bottom + 8 + 'px';
  popup.style.right = '16px';
});

document.getElementById('menuSettings').addEventListener('click', () => {
  window.location.href = '/v2-settings';
});

document.getElementById('menuHistory').addEventListener('click', () => {
  window.location.href = '/v2-history';
});

document.getElementById('menuShortcuts').addEventListener('click', () => {
  document.getElementById('addShortcutBtn').click();
});

document.getElementById('menuClearHistory').addEventListener('click', () => {
  if (confirm('Clear all browser history?')) {
    localStorage.removeItem(BROWSER_HISTORY_KEY);
    loadRecentlyVisited();
  }
});

document.getElementById('menuAbout').addEventListener('click', () => {
  alert('NovaSearch V2\nA lightweight search engine and browser.\n\nVersion 2.0\nBuilt with Node.js + vanilla JavaScript\nNo external APIs required.');
});

// ── Utilities ────────────────────────────────────────────────────────────

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// ── Init ─────────────────────────────────────────────────────────────────

loadShortcuts();
loadRecentlyVisited();

// Close menus on click outside
document.addEventListener('click', (e) => {
  if (!e.target.closest('#homeMenuBtn')) {
    document.getElementById('homeMenuPopup').style.display = 'none';
  }
});
