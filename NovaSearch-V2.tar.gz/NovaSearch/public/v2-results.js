'use strict';

// ── Theme ────────────────────────────────────────────────────────────────

const THEME_KEY = 'nova-theme';
const SHORTCUTS_KEY = 'nova-shortcuts';

function applyTheme(t) {
  document.documentElement.setAttribute('data-theme', t);
  document.getElementById('themeToggle').textContent = t === 'dark' ? '☀️' : '🌙';
}

(function initTheme() {
  const saved = localStorage.getItem(THEME_KEY);
  const preferred = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  applyTheme(saved || preferred);
})();

document.getElementById('themeToggle').addEventListener('click', () => {
  const next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
  applyTheme(next);
  localStorage.setItem(THEME_KEY, next);
});

// ── State ────────────────────────────────────────────────────────────────

const params = new URLSearchParams(window.location.search);
let currentQuery    = params.get('q') || '';
let currentPage     = parseInt(params.get('page') || '1', 10);
let currentCategory = params.get('cat') || 'all';
let menuTargetUrl   = null;

// ── DOM refs ─────────────────────────────────────────────────────────────

const searchInput  = document.getElementById('resultsSearchInput');
const resultsList  = document.getElementById('resultsList');
const resultsMeta  = document.getElementById('resultsMeta');
const pagination   = document.getElementById('pagination');
const stateLoading = document.getElementById('stateLoading');
const stateEmpty   = document.getElementById('stateEmpty');
const stateError   = document.getElementById('stateError');
const resultMenu   = document.getElementById('resultMenu');

// ── Init ─────────────────────────────────────────────────────────────────

searchInput.value = currentQuery;
document.title    = currentQuery ? `${currentQuery} — NovaSearch` : 'NovaSearch';

// Active category tab
document.querySelectorAll('.v2-category-btn').forEach(btn => {
  if (btn.dataset.category === currentCategory) btn.classList.add('active');
  else btn.classList.remove('active');

  btn.addEventListener('click', () => {
    document.querySelectorAll('.v2-category-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentCategory = btn.dataset.category;
    currentPage = 1;
    navigateToSearch(currentQuery, currentCategory, 1);
  });
});

document.getElementById('backHomeBtn').addEventListener('click', () => {
  window.location.href = '/';
});

searchInput.addEventListener('keydown', e => {
  if (e.key === 'Enter') {
    const q = searchInput.value.trim();
    if (q) navigateToSearch(q, currentCategory, 1);
  }
});

function navigateToSearch(q, cat, page) {
  window.location.href = `/v2-results?q=${encodeURIComponent(q)}&cat=${cat}&page=${page}`;
}

// ── Search ────────────────────────────────────────────────────────────────

async function doSearch() {
  if (!currentQuery) { showEmpty(); return; }

  showLoading();

  try {
    if (currentCategory === 'images') {
      await searchImages();
    } else if (currentCategory === 'videos') {
      await searchVideos();
    } else if (currentCategory === 'news') {
      await searchNews();
    } else if (currentCategory === 'maps') {
      showMaps();
    } else {
      await searchAll();
    }
  } catch (err) {
    showErrorState('Could not reach NovaSearch server. Make sure it is running.');
  }
}

async function searchAll() {
  const res  = await fetch(`/api/search?q=${encodeURIComponent(currentQuery)}&page=${currentPage}`);
  const data = await res.json();

  if (!data.results || data.results.length === 0) { showEmpty(); return; }

  hideStates();
  resultsMeta.style.display = 'block';
  resultsMeta.textContent   = `About ${data.total} results  (${data.searchTime || 0}ms)`;

  resultsList.innerHTML = data.results.map((r, i) => buildResultCard(r, i, currentPage)).join('');
  buildPagination(data.total, data.totalPages, currentPage);
  attachResultMenus();

  // AI overview
  fetchAiOverview(currentQuery, data.results.slice(0, 5));
}

async function searchImages() {
  const res  = await fetch(`/api/images?q=${encodeURIComponent(currentQuery)}&page=${currentPage}`);
  const data = await res.json();

  if (!data.results || data.results.length === 0) { showEmpty(); return; }

  hideStates();
  resultsMeta.style.display = 'block';
  resultsMeta.textContent   = `${data.total} images indexed`;

  resultsList.innerHTML = `<div class="v2-image-grid">${
    data.results.map(r => `
      <div class="v2-image-item" onclick="openInBrowser('${escHtml(r.url)}')">
        <img src="${escHtml(r.url)}" alt="${escHtml(r.alt_text)}" loading="lazy"
             onerror="this.parentElement.style.display='none'"/>
        <div class="v2-image-caption">${escHtml(r.alt_text || r.domain)}</div>
      </div>
    `).join('')
  }</div>`;
}

async function searchVideos() {
  const res  = await fetch(`/api/videos?q=${encodeURIComponent(currentQuery)}&page=${currentPage}`);
  const data = await res.json();

  if (!data.results || data.results.length === 0) { showEmpty(); return; }

  hideStates();
  resultsMeta.style.display = 'block';
  resultsMeta.textContent   = `${data.total} videos indexed`;

  resultsList.innerHTML = data.results.map(r => `
    <div class="v2-video-card" onclick="openInBrowser('${escHtml(r.url)}')">
      <div class="v2-video-thumb">
        ${r.thumbnail_url
          ? `<img src="${escHtml(r.thumbnail_url)}" alt="${escHtml(r.title)}" loading="lazy"
                  onerror="this.parentElement.innerHTML='▶️'"/>`
          : '▶️'}
      </div>
      <div class="v2-video-info">
        <div class="v2-video-title">${escHtml(r.title)}</div>
        <div class="v2-video-domain">${escHtml(r.domain)}</div>
      </div>
    </div>
  `).join('');
}

async function searchNews() {
  const res  = await fetch(`/api/news?q=${encodeURIComponent(currentQuery)}&page=${currentPage}`);
  const data = await res.json();

  if (!data.results || data.results.length === 0) { showEmpty(); return; }

  hideStates();
  resultsMeta.style.display = 'block';
  resultsMeta.textContent   = `${data.total} news articles indexed`;

  resultsList.innerHTML = data.results.map(r => `
    <div class="v2-news-card" onclick="openInBrowser('${escHtml(r.url)}')">
      <div class="v2-news-info">
        <div class="v2-news-source">${escHtml(r.source_domain)}</div>
        <div class="v2-news-title">${escHtml(r.title)}</div>
        <div class="v2-news-snippet">${escHtml(r.snippet)}</div>
        ${r.published_at ? `<div class="v2-news-date">${formatDate(r.published_at)}</div>` : ''}
      </div>
    </div>
  `).join('');
}

function showMaps() {
  hideStates();
  resultsMeta.style.display = 'block';
  resultsMeta.textContent   = 'Maps';
  resultsList.innerHTML = `
    <div class="v2-state">
      <div class="v2-state-icon">🗺️</div>
      <div class="v2-state-title">Open in Maps</div>
      <div class="v2-state-msg">
        NovaSearch doesn't have its own map.<br>
        Tap below to open your device's map app.
      </div>
      <a class="v2-btn v2-btn-primary" style="display:inline-block;margin-top:16px;text-decoration:none"
         href="geo:0,0?q=${encodeURIComponent(currentQuery)}">
        📍 Open Maps
      </a>
    </div>
  `;
}

// ── Result card builder ───────────────────────────────────────────────────

function buildResultCard(r, index, page) {
  const num     = (page - 1) * 10 + index + 1;
  const domain  = getDomain(r.url);
  const score   = r.score || 0;
  const scoreCls = score >= 0.6 ? 'score-high' : score >= 0.3 ? 'score-mid' : 'score-low';
  const scoreLabel = Math.round(score * 100) + '%';
  const snippet = highlight(r.snippet || r.description || '', currentQuery);
  const timeAgo = r.crawledAt ? getTimeAgo(new Date(r.crawledAt)) : '';

  return `
    <div class="v2-result-card" data-url="${escHtml(r.url)}">
      <div class="v2-result-number">${num}.</div>
      <img class="v2-result-favicon"
           src="https://www.google.com/s2/favicons?domain=${encodeURIComponent(domain)}"
           alt="" loading="lazy"
           onerror="this.style.display='none'"/>
      <div class="v2-result-body" onclick="openInBrowser('${escHtml(r.url)}')">
        <div class="v2-result-domain">${escHtml(domain)}</div>
        <div class="v2-result-title">${highlight(r.title || domain, currentQuery)}</div>
        <div class="v2-result-snippet">${snippet}</div>
        <div class="v2-result-meta">
          <span class="v2-result-score ${scoreCls}">${scoreLabel}</span>
          ${timeAgo ? `<span>${timeAgo}</span>` : ''}
        </div>
      </div>
      <button class="v2-result-menu-btn" title="More" data-url="${escHtml(r.url)}">⋮</button>
    </div>
  `;
}

function attachResultMenus() {
  document.querySelectorAll('.v2-result-menu-btn').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      menuTargetUrl = btn.dataset.url;
      const rect = btn.getBoundingClientRect();
      resultMenu.style.display  = 'block';
      resultMenu.style.position = 'fixed';
      resultMenu.style.right    = '10px';
      resultMenu.style.top      = rect.bottom + 4 + 'px';
    });
  });

  document.getElementById('menuOpen').onclick      = () => { openInBrowser(menuTargetUrl); hideMenu(); };
  document.getElementById('menuNewTab').onclick     = () => { openNewTab(menuTargetUrl); hideMenu(); };
  document.getElementById('menuCopy').onclick       = () => { navigator.clipboard.writeText(menuTargetUrl); hideMenu(); };
  document.getElementById('menuAddShortcut').onclick = () => { addToShortcuts(menuTargetUrl); hideMenu(); };
  document.getElementById('menuExternal').onclick   = () => { window.open(menuTargetUrl, '_blank'); hideMenu(); };
}

function hideMenu() { resultMenu.style.display = 'none'; }

document.addEventListener('click', e => {
  if (!e.target.closest('.v2-result-menu-btn') && !e.target.closest('#resultMenu')) {
    hideMenu();
  }
});

// ── Pagination ────────────────────────────────────────────────────────────

function buildPagination(total, totalPages, page) {
  if (totalPages <= 1) { pagination.style.display = 'none'; return; }

  pagination.style.display = 'flex';
  let html = `
    <button class="v2-page-btn" ${page <= 1 ? 'disabled' : ''}
            onclick="navigateToSearch('${escHtml(currentQuery)}', '${currentCategory}', ${page - 1})">‹ Prev</button>
    <span style="font-size:14px;color:var(--text-secondary)">Page ${page} of ${totalPages}</span>
    <button class="v2-page-btn" ${page >= totalPages ? 'disabled' : ''}
            onclick="navigateToSearch('${escHtml(currentQuery)}', '${currentCategory}', ${page + 1})">Next ›</button>
  `;
  pagination.innerHTML = html;
}

// ── AI Overview ───────────────────────────────────────────────────────────

async function fetchAiOverview(query, topResults) {
  try {
    const res  = await fetch('/api/ai/overview', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ query, context: topResults }),
    });
    const data = await res.json();

    if (data.available === false) {
      // Show "unavailable" note quietly inside the overview box
      return;
    }

    if (data.answer) {
      document.getElementById('aiBody').textContent = data.answer;
      if (data.sources && data.sources.length) {
        document.getElementById('aiSources').innerHTML =
          'Sources: ' + data.sources.map(s => `<a href="${escHtml(s.url)}" style="color:var(--primary)">${escHtml(s.title || s.url)}</a>`).join(', ');
      }
      document.getElementById('aiOverview').style.display = 'block';
    }
  } catch {
    // AI is optional — silently skip
  }
}

// ── Helpers ───────────────────────────────────────────────────────────────

function openInBrowser(url) {
  window.location.href = `/browser?url=${encodeURIComponent(url)}`;
}

function openNewTab(url) {
  // If already inside browser, use parent's tabManager if available
  if (window.parent && window.parent.tabManager) {
    window.parent.tabManager.createTab(url);
  } else {
    window.open(`/browser?url=${encodeURIComponent(url)}`, '_blank');
  }
}

function addToShortcuts(url) {
  const domain = getDomain(url);
  const shortcuts = JSON.parse(localStorage.getItem(SHORTCUTS_KEY) || '[]');
  if (shortcuts.some(s => s.url === url)) { alert('Already in shortcuts'); return; }
  shortcuts.push({ id: Date.now(), url, name: domain, icon: '🌐' });
  localStorage.setItem(SHORTCUTS_KEY, JSON.stringify(shortcuts));
  alert('Added to shortcuts!');
}

function getDomain(url) {
  try { return new URL(url).hostname.replace(/^www\./, ''); } catch { return url; }
}

function highlight(text, query) {
  if (!text || !query) return escHtml(text || '');
  const escaped = escHtml(text);
  const terms   = query.trim().split(/\s+/).filter(Boolean).map(t => escRegex(t));
  if (!terms.length) return escaped;
  const re      = new RegExp(`(${terms.join('|')})`, 'gi');
  return escaped.replace(re, '<mark>$1</mark>');
}

function escRegex(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }

function escHtml(text) {
  if (!text) return '';
  const d = document.createElement('div');
  d.textContent = text;
  return d.innerHTML;
}

function getTimeAgo(date) {
  const diff  = Date.now() - date.getTime();
  const mins  = Math.floor(diff / 60000);
  if (mins < 60)  return mins + 'm ago';
  const hours = Math.floor(mins / 60);
  if (hours < 24) return hours + 'h ago';
  const days  = Math.floor(hours / 24);
  return days + 'd ago';
}

function formatDate(str) {
  try { return new Date(str).toLocaleDateString(); } catch { return str; }
}

function showLoading() {
  stateLoading.style.display = 'flex';
  stateEmpty.style.display   = 'none';
  stateError.style.display   = 'none';
  resultsList.innerHTML      = '';
  resultsMeta.style.display  = 'none';
  pagination.style.display   = 'none';
}

function hideStates() {
  stateLoading.style.display = 'none';
  stateEmpty.style.display   = 'none';
  stateError.style.display   = 'none';
}

function showEmpty() {
  hideStates();
  stateEmpty.style.display = 'flex';
  resultsMeta.style.display = 'none';
}

function showErrorState(msg) {
  hideStates();
  stateError.style.display = 'flex';
  document.getElementById('stateErrorMsg').textContent = msg;
}

// ── Boot ─────────────────────────────────────────────────────────────────

doSearch();
