'use strict';

// ── Theme ──────────────────────────────────────────────────────────────────

const THEME_KEY = 'novasearch-theme';

function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  document.getElementById('themeToggle').textContent = theme === 'dark' ? '☀️' : '🌙';
}

function initTheme() {
  const saved = localStorage.getItem(THEME_KEY);
  const preferred = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  applyTheme(saved || preferred);
}

document.getElementById('themeToggle').addEventListener('click', () => {
  const current = document.documentElement.getAttribute('data-theme');
  const next = current === 'dark' ? 'light' : 'dark';
  applyTheme(next);
  localStorage.setItem(THEME_KEY, next);
});

initTheme();

// ── Search ─────────────────────────────────────────────────────────────────

function doSearch() {
  const q = document.getElementById('searchInput').value.trim();
  if (!q) return;
  window.location.href = `/results?q=${encodeURIComponent(q)}`;
}

document.getElementById('searchBtn').addEventListener('click', doSearch);
document.getElementById('searchInput').addEventListener('keydown', e => {
  if (e.key === 'Enter') doSearch();
});

// ── Stats ──────────────────────────────────────────────────────────────────

async function loadStats() {
  const el = document.getElementById('homeStats');
  try {
    const res  = await fetch('/api/stats');
    const data = await res.json();
    const { totalPages, totalDomains, lastCrawl } = data;

    if (totalPages === 0) {
      el.innerHTML = '🕸 Index is empty — <a href="/admin">add websites to crawl</a>.';
    } else {
      const when = lastCrawl ? new Date(lastCrawl).toLocaleDateString() : 'never';
      el.innerHTML =
        `Searching <strong>${totalPages.toLocaleString()}</strong> indexed pages across ` +
        `<strong>${totalDomains}</strong> domain${totalDomains !== 1 ? 's' : ''} &mdash; last crawl ${when}`;
    }
  } catch {
    el.textContent = 'Could not load index stats.';
  }
}

loadStats();
