'use strict';

// ── Theme (shared) ─────────────────────────────────────────────────────────

const THEME_KEY = 'novasearch-theme';

function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  document.getElementById('themeToggle').textContent = theme === 'dark' ? '☀️' : '🌙';
}

(function initTheme() {
  const saved = localStorage.getItem(THEME_KEY);
  const preferred = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  applyTheme(saved || preferred);
})();

document.getElementById('themeToggle').addEventListener('click', () => {
  const current = document.documentElement.getAttribute('data-theme');
  const next = current === 'dark' ? 'light' : 'dark';
  applyTheme(next);
  localStorage.setItem(THEME_KEY, next);
});

// ── State ──────────────────────────────────────────────────────────────────

let currentQuery = '';
let currentPage  = 1;
let totalPages   = 1;

// ── URL helpers ────────────────────────────────────────────────────────────

function getParam(name) {
  return new URLSearchParams(window.location.search).get(name) || '';
}

function setParam(name, value) {
  const p = new URLSearchParams(window.location.search);
  p.set(name, value);
  window.history.replaceState(null, '', `?${p.toString()}`);
}

// ── DOM refs ───────────────────────────────────────────────────────────────

const inputEl      = document.getElementById('searchInput');
const searchBtn    = document.getElementById('searchBtn');
const metaEl       = document.getElementById('resultsMeta');
const areaEl       = document.getElementById('resultsArea');
const paginationEl = document.getElementById('pagination');

// ── Search ─────────────────────────────────────────────────────────────────

function doSearch(q, page = 1) {
  q = q.trim();
  if (!q) return;
  currentQuery = q;
  currentPage  = page;
  inputEl.value = q;
  setParam('q', q);
  setParam('page', page);
  document.title = `${q} — NovaSearch`;
  fetchResults(q, page);
}

async function fetchResults(q, page) {
  showLoading();
  try {
    const res  = await fetch(`/api/search?q=${encodeURIComponent(q)}&page=${page}`);
    const data = await res.json();

    if (!res.ok) {
      showError(data.error || 'Search request failed.');
      return;
    }

    totalPages = data.totalPages || 1;
    renderResults(data);
  } catch (err) {
    showError('Network error — is the server running?');
  }
}

// ── Render ─────────────────────────────────────────────────────────────────

function showLoading() {
  metaEl.innerHTML = '';
  areaEl.innerHTML = '<div class="spinner"></div>';
  paginationEl.innerHTML = '';
}

function showError(msg) {
  metaEl.innerHTML = '';
  areaEl.innerHTML = `
    <div class="state-box">
      <div class="state-icon">⚠️</div>
      <div class="state-title">Something went wrong</div>
      <div class="state-msg">${escHtml(msg)}</div>
    </div>`;
  paginationEl.innerHTML = '';
}

function renderResults(data) {
  const { query, total, results, searchTime, message } = data;

  // Meta bar
  if (total > 0) {
    metaEl.innerHTML =
      `<span class="count">${total.toLocaleString()} result${total !== 1 ? 's' : ''}</span>` +
      `<span class="sep">·</span>${escHtml(searchTime || '')}`;
  } else {
    metaEl.innerHTML = '';
  }

  // Results list
  if (!results || results.length === 0) {
    const hint = message
      ? `<p>${escHtml(message)}</p><a class="state-action" href="/admin">Go to Admin →</a>`
      : `<p>Try different keywords, or <a href="/admin">crawl more pages</a>.</p>`;

    areaEl.innerHTML = `
      <div class="state-box">
        <div class="state-icon">${message ? '🕸' : '🔍'}</div>
        <div class="state-title">${message ? 'Index is empty' : `No results for "${escHtml(query)}"`}</div>
        <div class="state-msg">${hint}</div>
      </div>`;
    paginationEl.innerHTML = '';
    return;
  }

  areaEl.innerHTML = results.map((r, i) => resultCard(r, i, query)).join('');
  renderPagination(data.page, totalPages);
}

function resultCard(r, index, query) {
  const titleHtml  = highlight(escHtml(r.title || r.url), query);
  const descHtml   = highlight(escHtml(r.description || ''), query);
  const displayUrl = truncateUrl(r.url, 80);
  const scoreCls   = r.score >= 0.6 ? 'score-high' : r.score >= 0.3 ? 'score-mid' : 'score-low';
  const crawledAgo = timeAgo(r.crawledAt);
  const faviconSrc = `https://www.google.com/s2/favicons?sz=16&domain_url=${encodeURIComponent(r.url)}`;

  return `
    <div class="result-card" style="animation-delay:${index * 40}ms">
      <div class="result-domain">
        <img class="favicon" src="${faviconSrc}" alt="" loading="lazy"
             onerror="this.style.display='none'" />
        ${escHtml(r.domain)} <span class="sep">›</span> ${escHtml(displayUrl)}
      </div>
      <a class="result-title" href="${escAttr(r.url)}" target="_blank" rel="noopener noreferrer">
        ${titleHtml}
      </a>
      <div class="result-desc">${descHtml || '<em style="color:var(--text-muted)">No description available.</em>'}</div>
      <div class="result-footer">
        <span class="score-badge ${scoreCls}">score ${r.score.toFixed(2)}</span>
        <span title="${escAttr(r.crawledAt)}">${crawledAgo}</span>
      </div>
    </div>`;
}

function renderPagination(page, total) {
  if (total <= 1) { paginationEl.innerHTML = ''; return; }

  const pages = [];
  const radius = 2;

  // Always show first, last, and pages within radius of current
  const visible = new Set([1, total]);
  for (let i = Math.max(1, page - radius); i <= Math.min(total, page + radius); i++) visible.add(i);

  let prev = 0;
  for (const p of [...visible].sort((a, b) => a - b)) {
    if (prev && p - prev > 1) pages.push({ type: 'gap' });
    pages.push({ type: 'page', n: p });
    prev = p;
  }

  let html = '';
  html += `<button class="page-btn" id="pgPrev" ${page <= 1 ? 'disabled' : ''}>← Prev</button>`;
  for (const item of pages) {
    if (item.type === 'gap') {
      html += `<span style="color:var(--text-muted);padding:0 4px">…</span>`;
    } else {
      html += `<button class="page-btn ${item.n === page ? 'active' : ''}" data-page="${item.n}">${item.n}</button>`;
    }
  }
  html += `<button class="page-btn" id="pgNext" ${page >= total ? 'disabled' : ''}>Next →</button>`;

  paginationEl.innerHTML = html;

  paginationEl.querySelectorAll('[data-page]').forEach(btn => {
    btn.addEventListener('click', () => doSearch(currentQuery, parseInt(btn.dataset.page)));
  });
  document.getElementById('pgPrev')?.addEventListener('click', () => doSearch(currentQuery, page - 1));
  document.getElementById('pgNext')?.addEventListener('click', () => doSearch(currentQuery, page + 1));
}

// ── Utilities ───────────────────────────────────────────────────────────────

function escHtml(s) {
  return String(s || '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function escAttr(s) {
  return String(s || '')
    .replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/'/g, '&#39;')
    .replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function truncateUrl(url, max) {
  try {
    const u = new URL(url);
    const full = u.hostname + u.pathname;
    return full.length > max ? full.slice(0, max) + '…' : full;
  } catch { return url.slice(0, max); }
}

/**
 * Wrap query terms in <mark> for highlighting.
 * Only highlights if result is safe HTML (already escaped).
 */
function highlight(html, query) {
  if (!query || !html) return html;
  const terms = query.trim().split(/\s+/).filter(t => t.length > 1)
    .sort((a, b) => b.length - a.length); // longest first

  for (const term of terms.slice(0, 8)) {
    const escaped = term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const re = new RegExp(`(${escaped})`, 'gi');
    html = html.replace(re, '<mark style="background:rgba(124,58,237,.18);color:inherit;border-radius:2px;padding:0 2px">$1</mark>');
  }
  return html;
}

function timeAgo(dateStr) {
  if (!dateStr) return '';
  const diff = Date.now() - new Date(dateStr).getTime();
  const s = Math.floor(diff / 1000);
  if (s < 60)   return `${s}s ago`;
  const m = Math.floor(s / 60);
  if (m < 60)   return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24)   return `${h}h ago`;
  const d = Math.floor(h / 24);
  return `${d}d ago`;
}

// ── Init ───────────────────────────────────────────────────────────────────

function doSearchFromInput() {
  const q = inputEl.value.trim();
  if (q) doSearch(q, 1);
}

searchBtn.addEventListener('click', doSearchFromInput);
inputEl.addEventListener('keydown', e => { if (e.key === 'Enter') doSearchFromInput(); });

// Load initial query from URL
const initQuery = getParam('q');
const initPage  = parseInt(getParam('page')) || 1;

if (initQuery) {
  doSearch(initQuery, initPage);
} else {
  areaEl.innerHTML = `
    <div class="state-box">
      <div class="state-icon">🔍</div>
      <div class="state-title">NovaSearch</div>
      <div class="state-msg">
        NovaSearch searches only its own indexed pages &mdash; not the wider internet.<br>
        <a class="state-action" href="/admin" style="margin-top:16px;display:inline-block">Crawl websites →</a>
      </div>
    </div>`;
}
