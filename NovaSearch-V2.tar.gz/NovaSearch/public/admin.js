'use strict';

// ── Theme ──────────────────────────────────────────────────────────────────

const THEME_KEY = 'novasearch-theme';

function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  document.getElementById('themeToggle').textContent = theme === 'dark' ? '☀️' : '🌙';
}

(function initTheme() {
  const saved = localStorage.getItem(THEME_KEY);
  const preferred = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  applyTheme(saved || preferred);
})();

document.getElementById('themeToggle').addEventListener('click', () => {
  const current = document.documentElement.getAttribute('data-theme');
  const next = current === 'dark' ? 'light' : 'dark';
  applyTheme(next);
  localStorage.setItem(THEME_KEY, next);
});

// ── Toast ──────────────────────────────────────────────────────────────────

let toastTimer = null;
function showToast(msg, type = 'success') {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.className = `toast ${type} show`;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { el.className = `toast ${type}`; }, 3000);
}

// ── Refs ───────────────────────────────────────────────────────────────────

const seedUrlEl   = document.getElementById('seedUrl');
const maxPagesEl  = document.getElementById('maxPages');
const maxDepthEl  = document.getElementById('maxDepth');
const sameDomEl   = document.getElementById('sameDomain');
const startBtn    = document.getElementById('startBtn');
const stopBtn     = document.getElementById('stopBtn');
const resetBtn    = document.getElementById('resetBtn');

const statusBadge = document.getElementById('statusBadge');
const statusText  = document.getElementById('statusText');
const statCrawled = document.getElementById('statCrawled');
const statSkipped = document.getElementById('statSkipped');
const statErrors  = document.getElementById('statErrors');
const statIndexed = document.getElementById('statIndexed');
const currentUrlEl= document.getElementById('currentUrl');

const pagesBody   = document.getElementById('pagesBody');
const pagesCount  = document.getElementById('pagesCount');
const pagesRange  = document.getElementById('pagesRange');
const pagesPrev   = document.getElementById('pagesPrev');
const pagesNext   = document.getElementById('pagesNext');
const sessionsBody= document.getElementById('sessionsBody');

// ── Pagination state ───────────────────────────────────────────────────────

const PAGE_SIZE  = 20;
let pagesOffset  = 0;
let pagesTotal   = 0;

// ── Polling ────────────────────────────────────────────────────────────────

let pollInterval = null;

function startPolling() {
  if (pollInterval) return;
  pollInterval = setInterval(refreshStatus, 1500);
}

function stopPolling() {
  clearInterval(pollInterval);
  pollInterval = null;
}

// ── Status refresh ─────────────────────────────────────────────────────────

async function refreshStatus() {
  try {
    const [statusRes, statsRes] = await Promise.all([
      fetch('/api/crawl/status'),
      fetch('/api/stats'),
    ]);
    const status = await statusRes.json();
    const stats  = await statsRes.json();

    renderStatus(status);
    statIndexed.textContent = (stats.totalPages || 0).toLocaleString();

    const isRunning = status.status === 'running' || status.status === 'stopping';

    startBtn.disabled = isRunning;
    stopBtn.disabled  = !isRunning;

    // When crawl finishes, refresh pages list too
    if (!isRunning) {
      stopPolling();
      loadPages();
      loadSessions();
    }
  } catch {
    // Server might not be ready yet
  }
}

function renderStatus(s) {
  const status = s.status || 'idle';

  // Badge class
  statusBadge.className = `status-indicator status-${status}`;
  statusText.textContent = {
    idle:     'Idle',
    running:  'Running…',
    stopping: 'Stopping…',
    finished: 'Finished',
    stopped:  'Stopped',
    error:    'Error',
  }[status] || status;

  statCrawled.textContent = (s.pagesCrawled || 0).toLocaleString();
  statSkipped.textContent = (s.pagesSkipped || 0).toLocaleString();
  statErrors.textContent  = (s.errors       || 0).toLocaleString();
  currentUrlEl.textContent= s.currentUrl || '—';
}

// ── Start crawl ────────────────────────────────────────────────────────────

startBtn.addEventListener('click', async () => {
  const url      = seedUrlEl.value.trim();
  const maxPages = parseInt(maxPagesEl.value) || 50;
  const maxDepth = parseInt(maxDepthEl.value) || 2;
  const sameDomain = sameDomEl.checked;

  if (!url) { showToast('Please enter a seed URL.', 'error'); seedUrlEl.focus(); return; }
  if (!/^https?:\/\//i.test(url)) { showToast('URL must start with http:// or https://', 'error'); return; }

  startBtn.disabled = true;
  try {
    const res  = await fetch('/api/crawl', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url, maxPages, maxDepth, sameDomain }),
    });
    const data = await res.json();

    if (!res.ok) {
      showToast(data.error || 'Failed to start crawl.', 'error');
      startBtn.disabled = false;
      return;
    }

    showToast(`Crawling ${url} — up to ${maxPages} pages`);
    stopBtn.disabled = false;
    startPolling();
  } catch {
    showToast('Network error — server not reachable.', 'error');
    startBtn.disabled = false;
  }
});

// ── Stop crawl ─────────────────────────────────────────────────────────────

stopBtn.addEventListener('click', async () => {
  stopBtn.disabled = true;
  try {
    const res  = await fetch('/api/crawl/stop', { method: 'POST' });
    const data = await res.json();
    if (data.stopped) {
      showToast('Crawl stopped.');
      startBtn.disabled = false;
    } else {
      showToast(data.error || 'Could not stop crawl.', 'error');
      stopBtn.disabled = false;
    }
  } catch {
    showToast('Network error.', 'error');
    stopBtn.disabled = false;
  }
});

// ── Reset database ─────────────────────────────────────────────────────────

resetBtn.addEventListener('click', async () => {
  if (!confirm('This will delete ALL indexed pages and crawl history.\n\nAre you sure?')) return;

  try {
    const res  = await fetch('/api/admin/reset', { method: 'POST' });
    const data = await res.json();
    if (data.reset) {
      showToast('Index cleared successfully.');
      pagesOffset = 0;
      loadPages();
      loadSessions();
      refreshStatus();
    } else {
      showToast(data.error || 'Reset failed.', 'error');
    }
  } catch {
    showToast('Network error.', 'error');
  }
});

// ── Pages table ────────────────────────────────────────────────────────────

async function loadPages() {
  try {
    const res  = await fetch(`/api/admin/pages?limit=${PAGE_SIZE}&offset=${pagesOffset}`);
    const data = await res.json();
    pagesTotal = data.total || 0;
    renderPages(data.pages || []);
  } catch {
    pagesBody.innerHTML = '<tr><td colspan="5" class="table-empty">Failed to load pages.</td></tr>';
  }
}

function renderPages(pages) {
  pagesCount.textContent = `${pagesTotal.toLocaleString()} total`;

  const from = pagesOffset + 1;
  const to   = Math.min(pagesOffset + PAGE_SIZE, pagesTotal);
  pagesRange.textContent = pagesTotal === 0 ? '' : `${from}–${to} of ${pagesTotal}`;

  pagesPrev.disabled = pagesOffset <= 0;
  pagesNext.disabled = pagesOffset + PAGE_SIZE >= pagesTotal;

  if (pages.length === 0) {
    pagesBody.innerHTML = '<tr><td colspan="5" class="table-empty">No pages indexed yet.</td></tr>';
    return;
  }

  pagesBody.innerHTML = pages.map(p => `
    <tr>
      <td class="col-title" title="${escAttr(p.title)}">${escHtml(p.title || '(no title)')}</td>
      <td class="col-domain">${escHtml(p.domain)}</td>
      <td class="col-url"><a href="${escAttr(p.url)}" target="_blank" rel="noopener" title="${escAttr(p.url)}">${escHtml(truncate(p.url, 50))}</a></td>
      <td style="white-space:nowrap">${shortDate(p.crawled_at)}</td>
      <td>
        <button class="delete-btn" data-id="${p.id}" title="Remove from index">🗑</button>
      </td>
    </tr>
  `).join('');

  pagesBody.querySelectorAll('.delete-btn').forEach(btn => {
    btn.addEventListener('click', () => deletePage(btn.dataset.id));
  });
}

async function deletePage(id) {
  try {
    const res = await fetch(`/api/admin/pages/${id}`, { method: 'DELETE' });
    if (res.ok) {
      showToast('Page removed from index.');
      loadPages();
    } else {
      showToast('Could not delete page.', 'error');
    }
  } catch {
    showToast('Network error.', 'error');
  }
}

pagesPrev.addEventListener('click', () => {
  pagesOffset = Math.max(0, pagesOffset - PAGE_SIZE);
  loadPages();
});
pagesNext.addEventListener('click', () => {
  pagesOffset += PAGE_SIZE;
  loadPages();
});

// ── Sessions ───────────────────────────────────────────────────────────────

async function loadSessions() {
  try {
    const res      = await fetch('/api/admin/sessions');
    const sessions = await res.json();
    renderSessions(sessions);
  } catch {
    sessionsBody.innerHTML = '<div class="table-empty">Failed to load sessions.</div>';
  }
}

function renderSessions(sessions) {
  if (!sessions || sessions.length === 0) {
    sessionsBody.innerHTML = '<div class="table-empty" style="padding:20px">No crawl sessions yet.</div>';
    return;
  }

  sessionsBody.innerHTML = sessions.map(s => {
    const statusColor = {
      running: 'var(--score-high)',
      finished:'var(--nova-blue)',
      stopped: 'var(--score-mid)',
      error:   '#ef4444',
    }[s.status] || 'var(--text-muted)';

    return `
      <div class="session-item" style="padding:12px 20px">
        <div class="session-seed">${escHtml(s.seed_url)}</div>
        <div class="session-meta">
          <span style="color:${statusColor};font-weight:600">${escHtml(s.status)}</span>
          <span>📄 ${s.pages_crawled} crawled</span>
          <span>⏭ ${s.pages_skipped} skipped</span>
          <span>❌ ${s.errors} errors</span>
          <span>🕐 ${shortDate(s.started_at)}</span>
        </div>
      </div>`;
  }).join('');
}

// ── Utilities ──────────────────────────────────────────────────────────────

function escHtml(s) {
  return String(s || '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function escAttr(s) {
  return String(s || '')
    .replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/'/g, '&#39;')
    .replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function truncate(s, max) {
  s = String(s || '');
  return s.length > max ? s.slice(0, max) + '…' : s;
}

function shortDate(str) {
  if (!str) return '—';
  try {
    return new Date(str).toLocaleString(undefined, {
      month: 'short', day: 'numeric',
      hour: '2-digit', minute: '2-digit',
    });
  } catch { return str; }
}

// ── Init ───────────────────────────────────────────────────────────────────

(async function init() {
  await refreshStatus();
  await Promise.all([loadPages(), loadSessions()]);

  // If crawler is already running when page loads, start polling
  const statusRes = await fetch('/api/crawl/status').catch(() => null);
  if (statusRes) {
    const s = await statusRes.json().catch(() => ({}));
    if (s.status === 'running') {
      startBtn.disabled = true;
      stopBtn.disabled  = false;
      startPolling();
    }
  }
})();
