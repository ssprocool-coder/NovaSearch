# NovaSearch V2 — Search Engine + Browser

## Quick Start (Termux / Linux)
```bash
tar xzf NovaSearch-V2.tar.gz
cd NovaSearch
npm install
npm start
# → http://localhost:3000
```

## What's New in V2

| Feature | Status |
|---|---|
| Browser-style homepage with shortcuts | ✅ |
| In-app browser with tab system | ✅ |
| Search history + suggestions | ✅ |
| Recently visited pages | ✅ |
| Image indexing + image search | ✅ |
| Video reference detection | ✅ |
| News article detection | ✅ |
| Maps (Android intent) | ✅ |
| AI overview abstraction layer | ✅ |
| History page (search + browser) | ✅ |
| Settings page | ✅ |
| Android WebView shell | ✅ |
| Dark / light theme | ✅ |

## Pages
| URL | Description |
|---|---|
| `/` | V2 Homepage with shortcuts |
| `/browser?url=...` | In-app browser with tabs |
| `/v2-results?q=...&cat=all` | Search results |
| `/v2-results?q=...&cat=images` | Image search |
| `/v2-results?q=...&cat=videos` | Video search |
| `/v2-results?q=...&cat=news` | News results |
| `/v2-history` | Search + browser history |
| `/v2-settings` | App settings |
| `/admin` | Crawler admin (V1) |

## API
| Endpoint | Description |
|---|---|
| `GET /api/search?q=&page=` | Full-text search |
| `GET /api/images?q=&page=` | Image search |
| `GET /api/videos?q=&page=` | Video search |
| `GET /api/news?q=&page=` | News search |
| `GET /api/ai/status` | AI provider status |
| `POST /api/ai/overview` | Generate AI overview |
| `GET /api/stats` | Index stats |
| `POST /api/crawl` | Start crawl |
| `POST /api/crawl/stop` | Stop crawl |
| `GET /api/crawl/status` | Crawl status |
| `POST /api/admin/reset` | Reset index |

## Enable AI Overview (optional)
Create a `.env` file:
```
NOVA_AI_PROVIDER=anthropic
NOVA_AI_KEY=sk-ant-your-key-here
```
Or use OpenAI:
```
NOVA_AI_PROVIDER=openai
NOVA_AI_KEY=sk-your-key-here
```
Core search works fine with no AI configured.

## Android App
See `android/MainActivity.kt` — copy into Android Studio project.
On emulator use `10.0.2.2:3000` instead of `localhost:3000`.

## File Structure
```
NovaSearch/
├── server/
│   ├── server.js      Express app + all routes
│   ├── crawler.js     Web crawler
│   ├── parser.js      HTML → content + media extraction
│   ├── search.js      FTS search
│   ├── ranker.js      BM25 ranking
│   ├── database.js    JSON storage (no native deps)
│   ├── images.js      Image indexing
│   ├── videos.js      Video detection
│   ├── news.js        News detection
│   ├── ai.js          AI overview layer
│   ├── robots.js      robots.txt
│   └── url-utils.js   URL validation
├── public/
│   ├── v2-index.html  Homepage
│   ├── v2-styles.css  V2 styles
│   ├── v2-app.js      Homepage logic
│   ├── browser.html   In-app browser
│   ├── v2-browser.js  Tab manager
│   ├── v2-results.html Results (all/images/videos/news)
│   ├── v2-results.css Results styles
│   ├── v2-results.js  Results logic
│   ├── v2-history.html History page
│   ├── v2-settings.html Settings page
│   └── admin.html     V1 Admin
├── android/
│   ├── MainActivity.kt Android WebView shell
│   └── AndroidManifest.xml
└── data/
    └── novasearch.json Index (JSON, no SQLite)
```
