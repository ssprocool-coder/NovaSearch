'use strict';
/* NovaSearch V2 — Settings page */

document.addEventListener('DOMContentLoaded', () => {
  // Dark mode toggle
  const darkToggle = document.getElementById('darkModeToggle');
  if (getTheme() === 'dark') darkToggle.classList.add('on');

  // Load AI config
  loadAIConfig();

  // AI provider selector
  const providerSel = document.getElementById('aiProvider');
  providerSel.onchange = () => updateAIFields(providerSel.value);

  // Load saved settings
  const settings = getSettings();
  applySettingToggle('suggestions',     'suggestToggle',    settings);
  applySettingToggle('saveSearchHist',  'searchHistToggle', settings);
  applySettingToggle('saveBrowseHist',  'browseHistToggle', settings);
});

function getSettings() {
  try { return JSON.parse(localStorage.getItem('nova-settings') || '{}'); } catch { return {}; }
}
function saveSettings(s) { localStorage.setItem('nova-settings', JSON.stringify(s)); }

function applySettingToggle(key, id, settings) {
  const toggle = document.getElementById(id);
  if (!toggle) return;
  const val = settings[key] !== false; // default on
  toggle.classList.toggle('on', val);
}

function toggleSetting(key, btn) {
  const settings = getSettings();
  settings[key] = !btn.classList.contains('on');
  btn.classList.toggle('on');
  saveSettings(settings);
}
window.toggleSetting = toggleSetting;

function toggleDark() {
  toggleTheme();
  const darkToggle = document.getElementById('darkModeToggle');
  darkToggle.classList.toggle('on', getTheme() === 'dark');
}
window.toggleDark = toggleDark;

async function loadAIConfig() {
  try {
    const r = await fetch('/api/ai/config');
    const cfg = await r.json();
    const providerSel = document.getElementById('aiProvider');
    providerSel.value = cfg.provider || 'none';
    if (cfg.endpoint) {
      document.getElementById('aiEndpoint').value = cfg.endpoint;
      document.getElementById('aiEndpointOAI').value = cfg.endpoint;
    }
    if (cfg.model) {
      document.getElementById('aiModel').value = cfg.model;
      document.getElementById('aiModelOAI').value = cfg.model;
    }
    updateAIFields(cfg.provider || 'none');
  } catch { /* ignore */ }
}

function updateAIFields(provider) {
  document.getElementById('aiOllamaFields').style.display  = provider === 'ollama'  ? 'block' : 'none';
  document.getElementById('aiOpenAIFields').style.display  = provider === 'openai'  ? 'block' : 'none';
}
window.updateAIFields = updateAIFields;

async function saveAI() {
  const provider = document.getElementById('aiProvider').value;
  let endpoint = '', model = '', apiKey = '';
  if (provider === 'ollama') {
    endpoint = document.getElementById('aiEndpoint').value.trim();
    model    = document.getElementById('aiModel').value.trim();
  } else if (provider === 'openai') {
    endpoint = document.getElementById('aiEndpointOAI').value.trim();
    model    = document.getElementById('aiModelOAI').value.trim();
    apiKey   = document.getElementById('aiApiKey').value.trim();
  }
  try {
    const r = await fetch('/api/ai/config', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ provider, endpoint, model, apiKey }),
    });
    const data = await r.json();
    if (data.saved) showToast('AI settings saved!');
    else showToast('Error saving AI settings');
  } catch (err) { showToast('Error: ' + err.message); }
}
window.saveAI = saveAI;

function clearSearchHist() {
  clearSearchHistory();
  showToast('Search history cleared');
}
function clearBrowseHist() {
  clearBrowserHistory();
  showToast('Browsing history cleared');
}
window.clearSearchHist = clearSearchHist;
window.clearBrowseHist = clearBrowseHist;

async function resetIdx() {
  if (!confirm('Reset the entire search index? All crawled pages will be deleted.')) return;
  try {
    const r = await fetch('/api/admin/reset', { method: 'POST' });
    const data = await r.json();
    if (data.reset) showToast('Index reset successfully!');
  } catch (err) { showToast('Error: ' + err.message); }
}
window.resetIdx = resetIdx;
