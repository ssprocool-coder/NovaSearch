'use strict';
/* NovaSearch V2 — History Page */

let currentTab = 'browse';

document.addEventListener('DOMContentLoaded', () => {
  renderBrowse();
  renderSearch();

  document.getElementById('clearAllBtn').onclick = () => {
    if (currentTab === 'browse') {
      if (!confirm('Clear all browsing history?')) return;
      clearBrowserHistory();
      renderBrowse();
    } else {
      if (!confirm('Clear all search history?')) return;
      clearSearchHistory();
      renderSearch();
    }
    showToast('History cleared');
  };
});

function showTab(tab) {
  currentTab = tab;
  document.getElementById('tabBrowse').classList.toggle('active', tab === 'browse');
  document.getElementById('tabSearch').classList.toggle('active', tab === 'search');
  document.getElementById('browseList').style.display = tab === 'browse' ? '' : 'none';
  document.getElementById('searchList').style.display = tab === 'search' ? '' : 'none';
}
window.showTab = showTab;

function renderBrowse() {
  const list = document.getElementById('browseList');
  const hist = getBrowserHistory();
  if (!hist.length) {
    list.innerHTML = `<div class="empty-state"><div class="empty-state__icon">🌐</div><div class="empty-state__title">No browsing history</div><div class="empty-state__msg">Visit websites to see them here</div></div>`;
    return;
  }
  list.innerHTML = hist.map(h => {
    const domain = (() => { try { return new URL(h.url).hostname; } catch { return ''; } })();
    return `
      <div class="history-item" onclick="openHistItem('${escHtml(h.url)}','${escHtml(h.title||h.url)}')">
        <img class="history-item__favicon" src="https://${escHtml(domain)}/favicon.ico" onerror="this.style.display='none'">
        <div class="history-item__info">
          <div class="history-item__title">${escHtml(h.title || h.url)}</div>
          <div class="history-item__url">${escHtml(h.url)}</div>
        </div>
        <span class="history-item__time">${formatTime(h.time)}</span>
        <button class="history-item__del" onclick="deleteBrowseItem(event,'${escHtml(h.url)}')">✕</button>
      </div>`;
  }).join('');
}

function renderSearch() {
  const list = document.getElementById('searchList');
  const hist = getSearchHistory();
  if (!hist.length) {
    list.innerHTML = `<div class="empty-state"><div class="empty-state__icon">🔍</div><div class="empty-state__title">No search history</div><div class="empty-state__msg">Your searches will appear here</div></div>`;
    return;
  }
  list.innerHTML = hist.map(q => `
    <div class="history-item" onclick="window.location.href='/results?q=${encodeURIComponent(q)}'">
      <span style="font-size:1.1rem;flex-shrink:0">🔍</span>
      <div class="history-item__info">
        <div class="history-item__title">${escHtml(q)}</div>
      </div>
      <button class="history-item__del" onclick="deleteSearchItem(event,'${escHtml(q)}')">✕</button>
    </div>`).join('');
}

function openHistItem(url, title) {
  addBrowserHistory(title, url);
  window.location.href = `/browser?url=${encodeURIComponent(url)}&title=${encodeURIComponent(title)}`;
}
window.openHistItem = openHistItem;

function deleteBrowseItem(e, url) {
  e.stopPropagation();
  const hist = getBrowserHistory().filter(h => h.url !== decodeURIComponent(url));
  localStorage.setItem('nova-browser-history', JSON.stringify(hist));
  renderBrowse();
}
window.deleteBrowseItem = deleteBrowseItem;

function deleteSearchItem(e, q) {
  e.stopPropagation();
  const hist = getSearchHistory().filter(h => h !== decodeURIComponent(q));
  localStorage.setItem('nova-search-history', JSON.stringify(hist));
  renderSearch();
}
window.deleteSearchItem = deleteSearchItem;
