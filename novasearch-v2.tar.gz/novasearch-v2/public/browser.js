'use strict';
/* NovaSearch V2 — In-App Browser with Tab System */

// ── Tab State ────────────────────────────────────────────────────────────────
let tabs = [];      // [{ id, url, title, favicon, history, histIdx, loading }]
let activeTabId = null;
let tabIdSeq = 1;

// ── DOM refs ─────────────────────────────────────────────────────────────────
const tabBar      = document.getElementById('tabBar');
const newTabBtn   = document.getElementById('newTabBtn');
const backBtn     = document.getElementById('backBtn');
const fwdBtn      = document.getElementById('fwdBtn');
const reloadBtn   = document.getElementById('reloadBtn');
const addrInput   = document.getElementById('addrInput');
const progressBar = document.getElementById('progressBar');
const mainFrame   = document.getElementById('mainFrame');
const noPageMsg   = document.getElementById('noPageMsg');
const homeBtn     = document.getElementById('homeBtn');
const searchNavBtn= document.getElementById('searchNavBtn');
const newTabNavBtn= document.getElementById('newTabNavBtn');
const tabsBtn     = document.getElementById('tabsBtn');
const moreBtn     = document.getElementById('moreBtn');
const menuBtn     = document.getElementById('menuBtn');
const tabCountBadge = document.getElementById('tabCountBadge');

// ── Initialise ───────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  // Check if we have an initial URL from query params
  const params = new URLSearchParams(location.search);
  const initUrl   = params.get('url') || '';
  const initTitle = params.get('title') || '';

  // Create first tab
  const firstTab = createTab(initUrl, initTitle);
  switchTab(firstTab.id);

  if (initUrl) {
    navigate(initUrl, initTitle);
  }

  // Bind controls
  newTabBtn.onclick   = () => openNewTab();
  backBtn.onclick     = () => goBack();
  fwdBtn.onclick      = () => goForward();
  reloadBtn.onclick   = () => reloadCurrent();
  homeBtn.onclick     = () => window.location.href = '/';
  searchNavBtn.onclick= () => { const q = prompt('Search NovaSearch…'); if (q) window.location.href = `/results?q=${encodeURIComponent(q)}`; };
  newTabNavBtn.onclick= () => openNewTab();
  tabsBtn.onclick     = () => showTabSwitcher();
  moreBtn.onclick     = (e) => showMoreMenu(e);
  menuBtn.onclick     = (e) => showMoreMenu(e);

  addrInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { navigateToInput(); }
    if (e.key === 'Escape') { addrInput.blur(); syncAddrBar(); }
  });
  addrInput.addEventListener('focus', () => addrInput.select());

  // iframe load events
  mainFrame.addEventListener('load', onFrameLoad);
  mainFrame.addEventListener('error', onFrameError);

  // Android back button via popstate
  window.addEventListener('popstate', (e) => {
    if (getActiveTab()?.history?.length > 1) goBack();
    else window.location.href = '/';
  });
  history.pushState({}, '');
});

// ── Tab Management ───────────────────────────────────────────────────────────
function createTab(url = '', title = 'New Tab') {
  const tab = { id: tabIdSeq++, url, title, favicon: '', history: [], histIdx: -1, loading: false };
  if (url) { tab.history = [url]; tab.histIdx = 0; }
  tabs.push(tab);
  renderTabBar();
  return tab;
}

function getActiveTab() { return tabs.find(t => t.id === activeTabId) || null; }

function switchTab(id) {
  activeTabId = id;
  const tab = getActiveTab();
  renderTabBar();
  if (tab) {
    syncAddrBar();
    updateNavBtns();
    if (tab.url) {
      showFrame(tab.url);
    } else {
      showNoPage();
    }
  }
}

function closeTab(id) {
  const idx = tabs.findIndex(t => t.id === id);
  if (tabs.length <= 1) { tabs[0] = { ...tabs[0], url: '', title: 'New Tab', history: [], histIdx: -1 }; switchTab(tabs[0].id); return; }
  tabs.splice(idx, 1);
  if (activeTabId === id) {
    const newIdx = Math.min(idx, tabs.length - 1);
    switchTab(tabs[newIdx].id);
  } else {
    renderTabBar();
  }
}

function duplicateTab(id) {
  const src = tabs.find(t => t.id === id);
  if (!src) return;
  const dup = createTab(src.url, src.title);
  switchTab(dup.id);
  if (dup.url) navigate(dup.url, dup.title);
}

function openNewTab(url = '', title = '') {
  const tab = createTab(url, title);
  switchTab(tab.id);
  if (url) navigate(url, title);
  else addrInput.focus();
}

function renderTabBar() {
  // Remove existing tab elements (keep newTabBtn)
  tabBar.querySelectorAll('.tab').forEach(el => el.remove());

  for (const tab of tabs) {
    const el = document.createElement('div');
    el.className = 'tab' + (tab.id === activeTabId ? ' active' : '');
    el.dataset.id = tab.id;

    const faviconEl = document.createElement('img');
    faviconEl.className = 'tab__favicon';
    faviconEl.src = tab.favicon || '';
    faviconEl.onerror = () => { faviconEl.style.display = 'none'; };
    if (!tab.favicon) faviconEl.style.display = 'none';

    const titleEl = document.createElement('span');
    titleEl.className = 'tab__title';
    titleEl.textContent = tab.loading ? 'Loading…' : (tab.title || tab.url || 'New Tab');

    const closeEl = document.createElement('button');
    closeEl.className = 'tab__close';
    closeEl.innerHTML = '✕';
    closeEl.title = 'Close tab';
    closeEl.onclick = (e) => { e.stopPropagation(); closeTab(tab.id); };

    el.appendChild(faviconEl);
    el.appendChild(titleEl);
    el.appendChild(closeEl);
    el.onclick = () => switchTab(tab.id);
    el.oncontextmenu = (e) => { e.preventDefault(); showTabMenu(e, tab.id); };

    tabBar.insertBefore(el, newTabBtn);
  }

  // Scroll active tab into view
  const activeEl = tabBar.querySelector('.tab.active');
  if (activeEl) activeEl.scrollIntoView({ inline: 'center', behavior: 'smooth' });

  tabCountBadge.textContent = tabs.length;
}

// ── Navigation ───────────────────────────────────────────────────────────────
function navigateToInput() {
  let val = addrInput.value.trim();
  if (!val) return;

  // If it looks like a URL, treat as URL
  if (isUrlLike(val)) {
    if (!val.startsWith('http://') && !val.startsWith('https://')) val = 'https://' + val;
    navigate(val);
  } else {
    // Treat as search
    addSearchHistory(val);
    window.location.href = `/results?q=${encodeURIComponent(val)}`;
  }
}

function isUrlLike(str) {
  if (str.startsWith('http://') || str.startsWith('https://')) return true;
  if (/^[a-zA-Z0-9-]+\.[a-zA-Z]{2,}(\/|$)/.test(str)) return true;
  return false;
}

function isSafeScheme(url) {
  try {
    const u = new URL(url);
    return u.protocol === 'http:' || u.protocol === 'https:';
  } catch { return false; }
}

function navigate(url, title = '') {
  if (!isSafeScheme(url)) {
    showError('Unsafe URL', 'Only http:// and https:// URLs are supported.');
    return;
  }

  const tab = getActiveTab();
  if (!tab) return;

  // Push to tab history
  if (tab.histIdx < tab.history.length - 1) {
    tab.history = tab.history.slice(0, tab.histIdx + 1);
  }
  if (tab.history[tab.histIdx] !== url) {
    tab.history.push(url);
    tab.histIdx = tab.history.length - 1;
  }
  tab.url     = url;
  tab.title   = title || url;
  tab.loading = true;

  addrInput.value = url;
  showProgress(true);
  renderTabBar();
  updateNavBtns();
  showFrame(url);
  addBrowserHistory(title || url, url);
}

function showFrame(url) {
  noPageMsg.style.display = 'none';
  mainFrame.style.display = 'block';
  // Use the proxy endpoint to avoid CORS and keep navigation inside NovaSearch
  const proxyUrl = `/api/proxy?url=${encodeURIComponent(url)}`;
  mainFrame.src = proxyUrl;
  mainFrame.dataset.realUrl = url;
}

function showNoPage() {
  mainFrame.style.display = 'none';
  mainFrame.src = 'about:blank';
  noPageMsg.style.display = 'flex';
  addrInput.value = '';
  showProgress(false);
}

function onFrameLoad() {
  const tab = getActiveTab();
  if (!tab) return;
  tab.loading = false;
  showProgress(false);

  // Try to get title/favicon from frame
  try {
    const doc = mainFrame.contentDocument || mainFrame.contentWindow?.document;
    if (doc && doc.title && tab.url) {
      tab.title = doc.title;
      const iconEl = doc.querySelector('link[rel~="icon"]');
      if (iconEl) tab.favicon = iconEl.href;
      else {
        const domain = new URL(tab.url).hostname;
        tab.favicon = `https://${domain}/favicon.ico`;
      }
    }
  } catch { /* cross-origin — use domain favicon */ 
    if (tab.url) {
      try { tab.favicon = `https://${new URL(tab.url).hostname}/favicon.ico`; } catch {}
    }
  }

  // Intercept link clicks inside frame to open inside NovaSearch
  try {
    const doc = mainFrame.contentDocument;
    if (doc) {
      doc.addEventListener('click', (e) => {
        const a = e.target.closest('a');
        if (!a) return;
        const href = a.href;
        if (!href || !isSafeScheme(href)) return;
        e.preventDefault();
        if (a.target === '_blank') {
          openNewTab(href, a.textContent?.trim() || href);
        } else {
          navigate(href);
        }
      }, true);
    }
  } catch { /* cross-origin frames — navigation handled by proxy */ }

  renderTabBar();
  syncAddrBar();
  updateNavBtns();
  addBrowserHistory(tab.title, tab.url);
}

function onFrameError() {
  const tab = getActiveTab();
  if (tab) tab.loading = false;
  showProgress(false);
  renderTabBar();
}

function showProgress(active) {
  if (active) {
    progressBar.style.display = 'block';
    let w = 10;
    progressBar._interval = setInterval(() => {
      w = Math.min(w + Math.random() * 15, 85);
      progressBar.style.width = w + '%';
    }, 300);
  } else {
    clearInterval(progressBar._interval);
    progressBar.style.width = '100%';
    setTimeout(() => { progressBar.style.display = 'none'; progressBar.style.width = '0%'; }, 300);
  }
}

function showError(title, msg) {
  mainFrame.style.display = 'none';
  noPageMsg.innerHTML = `
    <div class="browser-error">
      <div class="browser-error__icon">⚠️</div>
      <div class="browser-error__title">${escHtml(title)}</div>
      <div class="browser-error__msg">${escHtml(msg)}</div>
      <button class="browser-error__retry" onclick="showNoPage()">Go Back</button>
    </div>`;
  noPageMsg.style.display = 'flex';
  showProgress(false);
}

function goBack() {
  const tab = getActiveTab();
  if (!tab || tab.histIdx <= 0) return;
  tab.histIdx--;
  const url = tab.history[tab.histIdx];
  tab.url = url;
  addrInput.value = url;
  showFrame(url);
  updateNavBtns();
}

function goForward() {
  const tab = getActiveTab();
  if (!tab || tab.histIdx >= tab.history.length - 1) return;
  tab.histIdx++;
  const url = tab.history[tab.histIdx];
  tab.url = url;
  addrInput.value = url;
  showFrame(url);
  updateNavBtns();
}

function reloadCurrent() {
  const tab = getActiveTab();
  if (!tab?.url) return;
  showProgress(true);
  mainFrame.src = mainFrame.src; // force reload
}

function updateNavBtns() {
  const tab = getActiveTab();
  backBtn.disabled  = !tab || tab.histIdx <= 0;
  fwdBtn.disabled   = !tab || tab.histIdx >= (tab.history.length - 1);
}

function syncAddrBar() {
  const tab = getActiveTab();
  addrInput.value = (tab?.url) || '';
}

// ── Tab Switcher UI ──────────────────────────────────────────────────────────
function showTabSwitcher() {
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:8888;display:flex;align-items:flex-end;padding:0';
  
  const sheet = document.createElement('div');
  sheet.style.cssText = 'background:var(--surface);border-radius:16px 16px 0 0;padding:16px;width:100%;max-height:70vh;overflow-y:auto';
  sheet.innerHTML = `<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
    <span style="font-weight:700;font-size:1.1rem">Tabs (${tabs.length})</span>
    <button onclick="openNewTabFromSwitcher()" style="background:var(--accent);color:#fff;border:none;border-radius:var(--radius-sm);padding:6px 14px;font-weight:600;cursor:pointer">+ New Tab</button>
  </div>`;

  const grid = document.createElement('div');
  grid.style.cssText = 'display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:8px';

  for (const tab of tabs) {
    const card = document.createElement('div');
    card.style.cssText = `background:var(--surface-2);border:2px solid ${tab.id === activeTabId ? 'var(--accent)' : 'var(--border)'};border-radius:var(--radius);padding:10px;cursor:pointer;position:relative;`;
    const domain = tab.url ? (() => { try { return new URL(tab.url).hostname; } catch { return ''; } })() : '';
    card.innerHTML = `
      <div style="font-size:.8rem;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;margin-bottom:4px">${escHtml(tab.title || 'New Tab')}</div>
      <div style="font-size:.72rem;color:var(--text-muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${escHtml(domain)}</div>
      <button style="position:absolute;top:4px;right:4px;background:none;border:none;color:var(--text-muted);cursor:pointer;font-size:.85rem;padding:2px 4px" data-closeid="${tab.id}">✕</button>`;
    card.querySelector('[data-closeid]').onclick = (e) => { e.stopPropagation(); closeTab(tab.id); overlay.remove(); if (tabs.length > 0) showTabSwitcher(); };
    card.onclick = (e) => { if (e.target.dataset.closeid) return; switchTab(tab.id); overlay.remove(); };
    grid.appendChild(card);
  }

  sheet.appendChild(grid);
  overlay.appendChild(sheet);
  document.body.appendChild(overlay);
  overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };

  window.openNewTabFromSwitcher = () => { overlay.remove(); openNewTab(); };
}

// ── Menus ────────────────────────────────────────────────────────────────────
function showTabMenu(e, tabId) {
  const tab = tabs.find(t => t.id === tabId);
  if (!tab) return;
  openCtxMenu([
    { icon: '🔄', label: 'Reload', action: () => { switchTab(tabId); reloadCurrent(); } },
    { icon: '⧉', label: 'Duplicate', action: () => duplicateTab(tabId) },
    { icon: '🔗', label: 'Open Externally', action: () => window.open(tab.url, '_blank') },
    'sep',
    { icon: '✕', label: 'Close Tab', action: () => closeTab(tabId), danger: true },
    { icon: '✕✕', label: 'Close Other Tabs', action: () => { tabs = tabs.filter(t => t.id === tabId); renderTabBar(); }, danger: true },
  ], e);
}

function showMoreMenu(e) {
  const tab = getActiveTab();
  openCtxMenu([
    { icon: '🏠', label: 'Home', action: () => window.location.href = '/' },
    { icon: '🔍', label: 'Search NovaSearch', action: () => window.location.href = '/results' },
    { icon: '📜', label: 'History', action: () => window.location.href = '/history' },
    { icon: '⚙️', label: 'Settings', action: () => window.location.href = '/settings' },
    'sep',
    ...(tab?.url ? [
      { icon: '📋', label: 'Copy Current URL', action: () => { navigator.clipboard.writeText(tab.url).catch(() => {}); showToast('URL copied!'); } },
      { icon: '🔗', label: 'Open Externally', action: () => window.open(tab.url, '_blank') },
      { icon: '🔖', label: 'Add to Shortcuts', action: () => { const shortcuts = getShortcuts(); if (!shortcuts.some(s => s.url === tab.url)) { shortcuts.push({ id: Date.now().toString(), name: (tab.title || tab.url).slice(0, 24), url: tab.url, emoji: '🌐' }); saveShortcuts(shortcuts); showToast('Added to shortcuts!'); } else { showToast('Already in shortcuts'); } } },
    ] : []),
    'sep',
    { icon: '➕', label: 'New Tab', action: () => openNewTab() },
  ], e);
}
